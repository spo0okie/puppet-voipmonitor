# FreeBSD

```
pkg install -y gmake pkgconf autoconf git libogg rrdtool google-perftools png fftw3 curl libvorbis vorbis-tools lzo2 snappy unixODBC json-c libgcrypt gbutls libssh icu
git clone https://github.com/voipmonitor/sniffer.git
autoconf
./configure
gmake
```
