#ifndef TOOLS_LOCAL_H
#define TOOLS_LOCAL_H


#include <sys/types.h>
#include "cloud_router/cloud_router.h"

#include "heap_safe.h"


#endif
