/* config.h.  Generated from config.h.in by configure.  */
/* config.h.in.  Generated from configure.in by autoheader.  */

/* Define to 1 if you have the declaration of `LN_aes_128_gcm', and to 0 if
   you don't. */
#define HAVE_DECL_LN_AES_128_GCM 1

/* Define if we have openssl >= 1.1.1 */
/* #undef HAVE_DSSL_TLS13 */

/* Define to 1 if you have the `c' library (-lc). */
#define HAVE_LIBC 1

/* Define to 1 if you have the `crypt' library (-lcrypt). */
#define HAVE_LIBCRYPT 1

/* Define to 1 if you have the `curl' library (-lcurl). */
#define HAVE_LIBCURL 1

/* Define if using libfftw3 */
/* #undef HAVE_LIBFFT */

/* Define to 1 if you have the `glib-2.0' library (-lglib-2.0). */
#define HAVE_LIBGLIB_2_0 1

/* Define if using gnutls */
#define HAVE_LIBGNUTLS 1

/* Define to 1 if you have the `icuuc' library (-licuuc). */
#define HAVE_LIBICUUC 1

/* Define to 1 if you have the `ltdl' library (-lltdl). */
#define HAVE_LIBLTDL 1

/* Define if using liblzma */
#define HAVE_LIBLZMA 1

/* Define if using liblzo */
#define HAVE_LIBLZO 1

/* Define to 1 if you have the `m' library (-lm). */
#define HAVE_LIBM 1

/* Define to 1 if you have the `mysqlclient' library (-lmysqlclient). */
#define HAVE_LIBMYSQLCLIENT 1

/* Define to 1 if you have the `odbc' library (-lodbc). */
#define HAVE_LIBODBC 1

/* Define to 1 if you have the `ogg' library (-logg). */
#define HAVE_LIBOGG 1

/* Define to 1 if you have the `pcap' library (-lpcap). */
#define HAVE_LIBPCAP 1

/* Define if using liblpng */
#define HAVE_LIBPNG 1

/* Define to 1 if you have the `pthread' library (-lpthread). */
#define HAVE_LIBPTHREAD 1

/* Define to 1 if you have the `rrd' library (-lrrd). */
#define HAVE_LIBRRD 1

/* Define to 1 if you have the `rt' library (-lrt). */
#define HAVE_LIBRT 1

/* Define to 1 if you have the `snappy' library (-lsnappy). */
#define HAVE_LIBSNAPPY 1

/* Define if using libtcmalloc_minimal */
/* #undef HAVE_LIBTCMALLOC */

/* Define if using libtcmalloc (with heap profiler) */
/* #undef HAVE_LIBTCMALLOC_HEAPPROF */

/* Define to 1 if you have the `vorbis' library (-lvorbis). */
#define HAVE_LIBVORBIS 1

/* Define to 1 if you have the `vorbisenc' library (-lvorbisenc). */
#define HAVE_LIBVORBISENC 1

/* Define to 1 if you have the `xml2' library (-lxml2). */
#define HAVE_LIBXML2 1

/* Define to 1 if you have the `z' library (-lz). */
#define HAVE_LIBZ 1

/* Define if using libtcmalloc */
#define HAVE_OPENSSL101 1

/* Define to the address where bug reports for this package should be sent. */
#define PACKAGE_BUGREPORT "support@voipmonitor.org"

/* Define to the full name of this package. */
#define PACKAGE_NAME "voipmonitor"

/* Define to the full name and version of this package. */
#define PACKAGE_STRING "voipmonitor VERSION"

/* Define to the one symbol short name of this package. */
#define PACKAGE_TARNAME "voipmonitor"

/* Define to the home page for this package. */
#define PACKAGE_URL ""

/* Define to the version of this package. */
#define PACKAGE_VERSION "VERSION"
