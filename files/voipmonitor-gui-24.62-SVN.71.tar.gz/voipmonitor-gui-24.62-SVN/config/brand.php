<?php

//define('BRAND_NAME', 'VoIPmonitor');
//define('BRAND_URL', 'http://voipmonitor.org');
//define('BRAND_WIKI', 'http://www.voipmonitor.org/doc/');
//define('BRAND_SITENAME', 'www.voipmonitor.org');
//define('BRAND_DOMAIN', 'voipmonitor.org');
//define('BRAND_BASE', 'voipmonitor');
//define('BRAND_DBNAME', 'voipmonitor');
//define('BRAND_SNIFFERNAME', 'voipmonitor');
//define('BRAND_SF_PROJECTNAME', 'voipmonitor');
//define('BRAND_DOWNLOAD', 'http://download.voipmonitor.org');
//define('BRAND_GETLICENSEKEY_URL', 'https://www.voipmonitor.org/getlicense');
//define('BRAND_GUINAME', 'voipmonitor-gui');
//define('BRAND_SHARESITE', 'share.voipmonitor.org');
//define('BRAND_LICENSEURL', 'http://www.voipmonitor.org/licenses');
//define('BRAND_FREETRIALURL', 'https://www.voipmonitor.org/getfreetrial');
//define('BRAND_CLOUDPRICEURL', 'http://www.voipmonitor.org/whmcs/cart.php?gid=2');
//define('BRAND_LOGO', 'logo.png');

//define('BRAND_NAME', 'YOUR NAME');
//define('BRAND_URL', 'http://YOUR URL');
//define('BRAND_WIKI', 'http://YOUR WIKI URL');
//define('BRAND_SITENAME', 'YOUR SITE NAME');
//define('BRAND_DOMAIN', 'YOUR DOMAIN');
//define('BRAND_BASE', 'YOUR BASE NAME');
//define('BRAND_DBNAME', 'YOUR DB NAME');
//define('BRAND_SNIFFERNAME', 'YOUR SNIFFER NAME');
//define('BRAND_SF_PROJECTNAME', 'voipmonitor');
//define('BRAND_DOWNLOAD', 'http://YOUR DOWNLOAD SITE');
//define('BRAND_GETLICENSEKEY_URL', 'https://YOUR GET LICENSE KEY SITE');
//define('BRAND_GUINAME', 'YOUR GUI NAME');
//define('BRAND_SHARESITE', 'YOUR SHARE SITE');
//define('BRAND_LICENSEURL', 'http://YOUR LICENSE URL');
//define('BRAND_FREETRIALURL', 'https://YOUR GET FREETRIAL URL');
//define('BRAND_CLOUDPRICEURL', 'http://YOUR CLOUD PRICE URL');
//define('BRAND_LOGO', 'logo-custom.png');

?>
