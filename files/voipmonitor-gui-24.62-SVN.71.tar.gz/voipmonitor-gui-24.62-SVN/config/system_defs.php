<?php //004d7
if(!extension_loaded('ionCube Loader')){

        $version = explode('.', PHP_VERSION);
        $path = ini_get('extension_dir');

        $arch = php_uname('m');
        $loader_file = "ioncube_loader_lin_".$version[0].".".$version[1].".so";
        if($arch == 'x86_64') {
                $loader_path = "x86_64/$loader_file";
        } else {
                $loader_path = "i686/$loader_file";
        }

        ?>

        <b>VoIPmonitor requires ioncube.com PHP Loader. Follow these installation instructions </b>

        <h3> Debian/Ubuntu or derivates </h3>
        <pre>
apt-get install wget
<?php
        echo "wget http://voipmonitor.org/ioncube/$loader_path -O $path/$loader_file\n";
        echo "echo \"zend_extension = $path/$loader_file\" > /etc/php5/apache2/conf.d/ioncube.ini\n";
        echo "/etc/init.d/apache2 restart\n";

        ?>
        </pre>
        <h3> Centos/Redhat or derivates </h3>
        <pre>
yum install wget
<?php

        echo "wget http://voipmonitor.org/ioncube/$loader_path -O $path/$loader_file\n";
        echo "echo \"zend_extension = $path/$loader_file\" > /etc/php.d/ioncube.ini\n";
        echo "/etc/init.d/httpd restart\n";

        die();
} else {
	print_r('blabla');
}

?>
HR+cPwmfVJ3wyqKurv/e4sDBfeZeec5vR6FSwU4x0dOPQZChbW0OxxA/qrVFZwgdvqokeOuZlXdd
uOSeZ0mZV4qcGvj0bhSTAIkENBvjIh9J4Dmopj1YYMxaROcrCwUOyUG4h9wXoV4lH2ItClLlEVUj
KWJUqCFglZwjUCOiVOy55SThzSu3bbxQ4veRmsHAATxNIXDgei359s/D2iix0dHILN+oBefbsgJA
QbxXxqGQjmHqOogaVfEkpN9PNwVqQ5bN0HO8exR/4SqBr6S5euokI1xp4dOw7vH6bZ2fBsaXnicr
1PqKxQo/kGF8mo1nzORYd5kwbRTeMgeVxPVVUi9HsXik8TFOg6ALbvnnWmqu+kp9aJ6KzV6YBpP3
39faOO1poPjXsw4sM31Q0RZj0dsIMWCdTGFn6HDqak/+yiCD4V0azLxhKnlgThefLen2/ow7jfEl
IvB9694wqZAbcFODOCdIlatJQRd932CParWHoywEJJIXWYexvr/A9kPPbbTuNHSzGYLEFV9bjuQ2
jWC3W7EfK17Zf3Jreh29qtjmS6WM1n7CEjyQMeiR5dDNe9RsF+6/VenLZDeg4qmh+xiPU88z5Q63
T+fv7nc6oZ+Ahp1G/3ujsryVs9RJCZGS6aXJL92yXb3WTgEjHzwgFS11ogjjignM/gODJv6vORYP
TdTiKhLJiuM62vO1ecHlus/HsJYhi2i6RfmPnnksHBFlGq1gBXSW35Y37nTAWZ+BtBHgP3xGxH8R
94dn0sL/c5D2HcpOt5pt724ENhuhWHe8RRMABKKAR8sxKoRt8FMzEuMp8K401yHjQRxWqOxOfHsa
G50lZBVO1tYQGMJIretoGKI4hvAwJZqqmxkBIJCm8JhukLvJsr8gcBSYwb5uTJBlLXWFzu4/1OEv
LDRhjZIcWvBuWw5/t+qkZfD7+EtIHms4JdoSByf+YqICoY6FPaDQ8fZuaMQqZ8e00ww0pB/8b1fQ
EcbpcaEFRYjnmJYZGbfJnLetvPeACUV0kR5hPqBrT959xllivNhLMgKlKaCUaikxCuz+nVDWUlgH
6O7AiBy36kZBTBBl6gc84sX/6jvavivNoMOkHyD7jQ6jnqHmeC9HXQ8VH2yVawws/bRx4YvtQa1s
6cepBPqtTyrAfDTCL3Crz9O7cZJvULNKzg3A9xRc9FEI/8ZYKiJua21akUF635z8QcQqq3Bv1YUd
37yF24s1yeWXmUEI8o1LcR1hhkEgFrjIQHL35fMFIeYnPtyEUaekqYP71eLn45t147bTYog4GYjI
4/SVpJYZcKy2y3I++wd8H9CN2sC6W8ZJTRXhxKdaPBPUK+78hlNtme0Xe26HL1/JxxDOKH/6+J7T
YbzN93lwlt9Bt4Nf02hs6xAErBo8Oef96tPuATOFzwp+CN1nTyKYHJBUNtInVv7pSFym5EdvA7h7
zGXG1+Q9JT/TUDirr32n08bLDYMRwOhY878arXcxjgTFJr05cNO3kKWT+OfgDLNBY90k1dNUlTFj
rKWO5hCVRFexVRBxGjk/q6mAu4NAkvUmuhbPIzmTVgzJmyIzhxARbxBBQZ0FxTrLPZySBcTnLsOE
GevBuOSwgbKoB2nAkUlwk/SvLvoKuIik/V5bQp4UIzhitdqZTbzJWeTHGGHW9LN2+yWlenRpGZV3
t9MJKR0qB4vkX29QJo+KCZjAp1xVwzUGbfRxywOmq/bUmz1ikyr9+wpCH3kvTNZdm0bzCdD72rbD
P4vY5/BvWQc6qXIaXS9sRHBWEe0qRoW55rr+sMENlM+6wt3z47ID3URRSPB0BSa4Wqk9s4CSupN/
KrAOT/0w/9W2C9D7FMk/IJ9jqh99fHLNk+Ggvyivx69U0Fs/pgr07M+KyZyOCrVeygGqfnvhItl/
QrbBMrfhG1RxJ06IQIJ36wpOuA4kCHrV