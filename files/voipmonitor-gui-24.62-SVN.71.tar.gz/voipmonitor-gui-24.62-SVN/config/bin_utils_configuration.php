<?PHP

define('WKHTMLTOPDF_VERSION', '12.4');
define('WKHTMLTOIMAGE_VERSION', '12.4');
define('TSHARK_VERSION', '2.3.0.3');
define('MERGECAP_VERSION', '2.3.0.3');
define('T38_DECODE_VERSION', '2');
define('PHANTOMJS_VERSION', '2.1.1');

?>
