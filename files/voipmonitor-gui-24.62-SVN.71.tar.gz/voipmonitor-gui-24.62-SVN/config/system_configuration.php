<?PHP

// define('DISABLE_LIVE_SNIFFER', true);
// define('DISABLE_ISSUE_TRACKER', true);
// define('DISABLE_REGISTER', true);
// define('DISABLE_CDR_SHARE', true);

// define('DOWNLOAD_WEB', 'http://download.voipmonitor.org');

// define('CALL_RECORDER', false);

define('UPGRADE_VERSIONS_URL', 'http://download.voipmonitor.org/senzor/list.txt');

define('FAVICON', '/favicon.ico');

?>
