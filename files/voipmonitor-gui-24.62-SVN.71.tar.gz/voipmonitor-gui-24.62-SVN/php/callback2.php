<?php //004d7
if(!extension_loaded('ionCube Loader')){

        $version = explode('.', PHP_VERSION);
        $path = ini_get('extension_dir');

        $arch = php_uname('m');
        $loader_file = "ioncube_loader_lin_".$version[0].".".$version[1].".so";
        if($arch == 'x86_64') {
                $loader_path = "x86_64/$loader_file";
        } else {
                $loader_path = "i686/$loader_file";
        }

        ?>

        <b>VoIPmonitor requires ioncube.com PHP Loader. Follow these installation instructions </b>

        <h3> Debian/Ubuntu or derivates </h3>
        <pre>
apt-get install wget
<?php
        echo "wget http://voipmonitor.org/ioncube/$loader_path -O $path/$loader_file\n";
        echo "echo \"zend_extension = $path/$loader_file\" > /etc/php5/apache2/conf.d/ioncube.ini\n";
        echo "/etc/init.d/apache2 restart\n";

        ?>
        </pre>
        <h3> Centos/Redhat or derivates </h3>
        <pre>
yum install wget
<?php

        echo "wget http://voipmonitor.org/ioncube/$loader_path -O $path/$loader_file\n";
        echo "echo \"zend_extension = $path/$loader_file\" > /etc/php.d/ioncube.ini\n";
        echo "/etc/init.d/httpd restart\n";

        die();
} else {
	print_r('blabla');
}

?>
HR+cPo7eUvADC42c75tkiRFg++TjPXiVCaJkkZwaHCj+eTq9M8PjNyitadrCTFgygz+1K+/lYgMC
XAOTLsrtXMn9kf7zyzruoouRYucNtYQ00gtcGXm+ZXAxBYLaCMLP64BOXFg/mPJPmevAjQf4kXAr
g0qFPRlxVl9ZV7oBr+mPubSIjuoZ2dc0y8TfSrzQMyYB9vuZP1YDmFZUkQ+CfYrKqBzK7gdmfzZe
n4ijTfdTgYHerPj79YYuMHpwEX/zlIXauEzKfI27rIkqtr8xv1dEH16wsLRzwMrwZ1sWuOVWfpdC
jP4oUuSuhd45lwNJ1Xq5C8Pcb41vBfVVUi9HsXkG2IuXqzYeOfMNd5o7mCrk0ci2QFdJxf8/UEHD
/szpJvKNdgbDXhtK7cfDJCjohDi3oDo+UTEe4X2UH2no3L65GGxPAFnMpzzAy+1neokYObXUx+9n
R2SJslR87wu0fxNUVJjHBPreN8Mmo/vjZ2Q6Cl5mwNOxQqOnsLxbhkHGRWfh1U+mH7DiRlNyIZd+
E+Pu6s/PM7TRuw1Zvxsa/0WJZuPL0wmeNZbsznUSjcc5AXPCH8zgM/SiXkXNPK7/bOtH4KAoh94C
prqAHLbKLubUPOmnZAD3FWy/FvVj4DWNyGHTHKY9Nb6C8ox1vXU137ISbKC5BvWM8RufYD/bqX7+
DflniCytu5EFOs1q/Pn2cZ1wx1QN/5FQKV3FJqkf0O2O+TQDsBKFYoiqPGGoRRUfqTffn+H7M7OV
ueeIvF0kTGAyyflGorzopyQgEN5/ONP4IXV9aOZeynoxuYmt2TiRkLcBOojMqX+EpIaP7EOVohEo
SnpKKBEJEHPf7p+EDXcbgszfqsRug532yKSe01xwaK20UmGb8XHp+gMHjKAUjvyVeeAo20ZKc3Uy
0nDoIm/QLom3buZH2J6dK1/+Dazp622w7W5fW8iWKbNgoG6JKGfXZ/4AscNuAiOqkE+dITkTWRlQ
L1YKP7sz9nFv/xcmducdL7fpfq19u+Z+09qshry5HZumGGbwg9XFdEelHaE8MhZLt7ygZ2d0YzXE
OQKWN6bkbmli/dqHlAljR5v8Wgchm/RnWa2jolwbcf1O6fRn7p4knoFVpjD19Df0QeYm7v1th3dd
UKJXZRYEN57dJdjhq0gixmBsvgX3nohVUKvWSr1Iz+cSEAmfLxyrsH2DnSQjQcfNTraGdd6S/2YL
y5iqh91+a2tF5p3yRRDJSj7V714IE8mA01MWLzmIjXQ+vQpvYz51q2cNewLwApeRhr1a3n24Eu+B
7Pa2J8WvAxRLTyHA2aW3VbOqqkDMpb708tXMw7jWwaI0mtc04fxuGb2IXear6suBnfuUHMTYSIVv
mnCRfhcNOG6EGZ/NKruG2Q/W9D8poNZSnNqVtTzCMZDLzzC+kpICnNIAjE8PQndpU5qnr64+PUUA
Mt5PH8pOd/tyHK51YOOYPBbdwkt18nj1VRFsFG3W7Nibf2EXE1u05jkSP/QRzXiRKJgNbcTEtIkF
uv3QiJh3hyiPZhPpECFc0MnaY9Q+Kd+w9Cm/EdQuGaw0PBDrLsNPbrPDCdmbezmCoXZjR/BoBmRq
5VhrwIj9CtrK+pUEYKiTjimPvuTsIZQbipu2hnqChICmdIlkhesQQ6h0cYdAZsvKTkm2CyId9z0a
Zm==