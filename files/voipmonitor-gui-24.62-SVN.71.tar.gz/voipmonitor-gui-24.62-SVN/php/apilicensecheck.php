<?php

define('MINIMAL_IONCUBE_VERSION_PHP7', 60009);
define('MINIMAL_IONCUBE_VERSION', 50012);

if (extension_loaded('ionCube Loader') && check_ioncube_version()) {
	require_once('../ioncubetest.php');
} else {
	echoResult(1, 'Properly ionCube version is not loaded.');
	exit;
}

if (!isset($_REQUEST['task'])) {
	echoResult(1, 'No task entered.');
	exit;
}

$task = $_REQUEST['task'];
if (!function_exists($task)) {
	echoResult(1, 'Bad task.');
	exit;
}
$task();
exit;

function licenseCheck() {
	$retval = api_key_check();
	if ($retval === false) {
		echoResult(0, 'License OK.');
	} else {
		echoResult(1, $retval);
	}
}

function check_ioncube_version() {
	$php_version = explode('.', PHP_VERSION);
	return(ioncube_loader_iversion() >= ($php_version[0] >= 7 ? MINIMAL_IONCUBE_VERSION_PHP7 : MINIMAL_IONCUBE_VERSION));
}

function echoResult($result, $text) {

	$rslt = new stdClass;
	$rslt->status = $result;
	$rslt->message = $text;
	echo json_encode($rslt);
}

?>
