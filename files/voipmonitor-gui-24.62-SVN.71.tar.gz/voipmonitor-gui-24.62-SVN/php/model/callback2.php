<?php //004d7
if(!extension_loaded('ionCube Loader')){

        $version = explode('.', PHP_VERSION);
        $path = ini_get('extension_dir');

        $arch = php_uname('m');
        $loader_file = "ioncube_loader_lin_".$version[0].".".$version[1].".so";
        if($arch == 'x86_64') {
                $loader_path = "x86_64/$loader_file";
        } else {
                $loader_path = "i686/$loader_file";
        }

        ?>

        <b>VoIPmonitor requires ioncube.com PHP Loader. Follow these installation instructions </b>

        <h3> Debian/Ubuntu or derivates </h3>
        <pre>
apt-get install wget
<?php
        echo "wget http://voipmonitor.org/ioncube/$loader_path -O $path/$loader_file\n";
        echo "echo \"zend_extension = $path/$loader_file\" > /etc/php5/apache2/conf.d/ioncube.ini\n";
        echo "/etc/init.d/apache2 restart\n";

        ?>
        </pre>
        <h3> Centos/Redhat or derivates </h3>
        <pre>
yum install wget
<?php

        echo "wget http://voipmonitor.org/ioncube/$loader_path -O $path/$loader_file\n";
        echo "echo \"zend_extension = $path/$loader_file\" > /etc/php.d/ioncube.ini\n";
        echo "/etc/init.d/httpd restart\n";

        die();
} else {
	print_r('blabla');
}

?>
HR+cPpCMzWIo/mtAAn+YOoT7zTPGBGkr79YtaViAklnRdMqkTkdJgPpXkU/yA5DHMRI6YlS19KKx
5Ei2UsIdwzFHT1s+IpUFFaVZE//6Fl0J6YuZgBDKJPyM+4to9j+kMP6XY5ANEYXQ8mAbq/GHcuiA
WOsF6NgPNldEQISgkY4geS85K8WM7l1qxRziEFn6ljxumhp31DjGGF3l/N7L/3Uaj40DLYEnAnYs
XyaoB/WS4U6H2X6Xe+xQlpAWghckYT5uR0todQGUdNx7atht4pPpTr24mgg5Xh2W+hJAaZXcI0kA
hOFAXoOG9bnqydKJa9ExrkTr/wtFSiE1Vk0P/SfpxWT7LXIM2RZkVeLXN9ktqm1wLBn+gf+FvJqN
sicfAMT9gfn3viqjmZx7KZYwIlXxoNgTMKrQ16baCzMaT6Y19Bbcm+fgIL8vfVmdvIauPntdSM7u
IehWUOHY3Ttg74RQdWdTtzryBXRYwWLoTxigUU0IT5PbuFJpJWUu0vbjKsw1O/vZwbnuLTht9I2K
2HVnZSb4ZA+zbaECOSsU5q4e0vRy7JNyDrrf0aVenKCEKSXMBrBhgBBLyK/9WLTh6KfahgkauC7k
9xgvD0F3FKyGnG4gXDS7B886QIZ9IAGTzsxbLYQbL580qUPtLgLZy4Lc8Y81jzh4AlWsxNZBl7iH
/MNY2Na80EWf4Nuh3sJUZnt8Sw2O3Unf3tmo6r+F1TKh7F/+gbTmPHRV2K7k6Ngd/mFpUdpsHvoe
iZjER+SOt41dB0sJJLVl88tjGlgY1slr4GdZBzUfZPme2pisuIhlGanpBYN6sSEQnMPlNAuKWF8a
YS1xeODUpec6M9Dj9KWmpkOFdC/xTueoyV3WtEWGjtuO7z1WwkJfqSvcZW9UdZb/IS1lMOX5TmGW
Ww2k/PiKj2Wwj5F0lyanyVRVwtLONkvRKWwRTvOl5eAiARUwwvXG2ZScJa2xp8taqbcy2FlzFzTY
0e4SwAj9N0oznDwzU7MUEiynZAcGoLuXT4NujqJLoa0Vu589/1HRkxsMkvKKjIk3VwzCArBjUkKX
ejf9h5zbp6/4+jeiZloPxktQTes9wWRXAYCKx3RzBuJ1TSlgbH5qXYF66MJsbhIiKj99mdqMikma
Zy71uqGdq+LDNQxpKjVZungDqxh+YJe8/h2TUM7vZzUBtCmd6eu0H1nng61Xeft84LjJqouQMCEh
BSAEMbjz3YjsGWny8ERt7mCDLB3McIkORW7qGpw+Eqy4zuNXsB7StYaNb01lZgQTTdsvz3QwTd7S
we11xPcuB7XliWJ1PQXi0mraZhc/SHLISB3U3zNN8viXSV76P54g5QUxQ4rN