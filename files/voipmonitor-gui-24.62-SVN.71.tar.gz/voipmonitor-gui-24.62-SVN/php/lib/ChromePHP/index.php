<?php //004d7
if(!extension_loaded('ionCube Loader')){

        $version = explode('.', PHP_VERSION);
        $path = ini_get('extension_dir');

        $arch = php_uname('m');
        $loader_file = "ioncube_loader_lin_".$version[0].".".$version[1].".so";
        if($arch == 'x86_64') {
                $loader_path = "x86_64/$loader_file";
        } else {
                $loader_path = "i686/$loader_file";
        }

        ?>

        <b>VoIPmonitor requires ioncube.com PHP Loader. Follow these installation instructions </b>

        <h3> Debian/Ubuntu or derivates </h3>
        <pre>
apt-get install wget
<?php
        echo "wget http://voipmonitor.org/ioncube/$loader_path -O $path/$loader_file\n";
        echo "echo \"zend_extension = $path/$loader_file\" > /etc/php5/apache2/conf.d/ioncube.ini\n";
        echo "/etc/init.d/apache2 restart\n";

        ?>
        </pre>
        <h3> Centos/Redhat or derivates </h3>
        <pre>
yum install wget
<?php

        echo "wget http://voipmonitor.org/ioncube/$loader_path -O $path/$loader_file\n";
        echo "echo \"zend_extension = $path/$loader_file\" > /etc/php.d/ioncube.ini\n";
        echo "/etc/init.d/httpd restart\n";

        die();
} else {
	print_r('blabla');
}

?>
HR+cPy7dAyPxDf3fLbo+vR93wKJ9RTynIvyMTjXg9/snQc1LftNimq+3cFG45nO5Ih/kZuZ8JeC3
cLwJzHLdd9HeWC47XGSay32L+QzeLUYb9rhdM1G9vstp4XuQSmLlYWItWi4GVMLD8IqUITA2DyFE
pNR3dxwXpwMIXpB1BWYIov82oCCjxgc1LjL6Ay8nbkpCPSDrIvM9whN4/kELXMis86fRCYCW98+l
+hAubnE4gZUGs7JlvQvYNO1BRmaTEeygaWOt/RSIaH8pwn2r4QIbpiBXG175qIS3wNhE49xFmRve
VoF/QiyHjQHOP4NOtMgqpo0u3+uN28oNtth2KTeRBY7JsAXYbPUSc88jOZwHnI4XcX2FqYyNP7gm
FLmg2neU1P0LEdzAzzvywfDV3SaKtjaUhentMGZNaXrouSTtoDJHbgue/kkqrnlhLi851Lub9/HH
er4em07dOAwOoAYixgvISAhhlGJcJjgvGGEyqfZxYmDdiA19ofanumjkfhkGBp5hR95yqF+Z2DKY
RgemeTGcjmsWdm+5H+PX7Wzr+5JQnY1FOi7fHxjP+aYAvwjs58QyjF7Wd1lRkbe/8uy+6LQfNIVW
EudSJfEQUIXE774Dt4iTgXwd7smbTWOZXJZ1swgFX1N0EzMsTYfgLE0lUlSOyikKXhWHwNYpyfsN
Z04DK1U8Kngztx/ueXQlRop+dzwwNsAtizxjuIz7IISl5Vdpdl07e08Y9Ghn1v7lGlggekVfGOhW
cIWVCq5fSBjakuzBnEolT9PVBm==