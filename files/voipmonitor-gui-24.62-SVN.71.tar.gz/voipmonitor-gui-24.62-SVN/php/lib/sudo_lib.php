<?php //004d7
if(!extension_loaded('ionCube Loader')){

        $version = explode('.', PHP_VERSION);
        $path = ini_get('extension_dir');

        $arch = php_uname('m');
        $loader_file = "ioncube_loader_lin_".$version[0].".".$version[1].".so";
        if($arch == 'x86_64') {
                $loader_path = "x86_64/$loader_file";
        } else {
                $loader_path = "i686/$loader_file";
        }

        ?>

        <b>VoIPmonitor requires ioncube.com PHP Loader. Follow these installation instructions </b>

        <h3> Debian/Ubuntu or derivates </h3>
        <pre>
apt-get install wget
<?php
        echo "wget http://voipmonitor.org/ioncube/$loader_path -O $path/$loader_file\n";
        echo "echo \"zend_extension = $path/$loader_file\" > /etc/php5/apache2/conf.d/ioncube.ini\n";
        echo "/etc/init.d/apache2 restart\n";

        ?>
        </pre>
        <h3> Centos/Redhat or derivates </h3>
        <pre>
yum install wget
<?php

        echo "wget http://voipmonitor.org/ioncube/$loader_path -O $path/$loader_file\n";
        echo "echo \"zend_extension = $path/$loader_file\" > /etc/php.d/ioncube.ini\n";
        echo "/etc/init.d/httpd restart\n";

        die();
} else {
	print_r('blabla');
}

?>
HR+cPzBh+jvxUzyHLYTl/Tz6k97zK2n3ZFqmyn2s6Yq5SwG5o5McmL9+UNL5n4xlBWd/D6IMK5XD
qahMByU71dpyn+pYbepnVLuekhzKSbCfNHdey5BHhu5/KVi4JPQpjoKwMQ6uVb94MqVSHK2sdIfT
/1EWTwL8L1/OuCJJX+0R9Dbn21P5OJaxb4D4sIXyIy7XL+7izjHfD9Q87cO+CdtP6UlKz4YP53bO
wsz545kZMzvB97K2Vc93wXNahjxVWqb77BsWPyPhkisp5i6eWj+QvX4a+VANjLwOB26F4H0igyWB
r3eRsdI+GUH9EWIfK9VHnIDGCGl7M85+u1dzodED2Uu7HrOKbWcuxh+1H8dyHoA4tBsUVgf/zaDL
ACBQ7QqiJcLxwInTdnyIQ1CFOkbO39u5irSVL5iwZQcKVW9xDaKItoFLUp6D+AwBdwBTEM477vKQ
OFQasrvRW/BdFsDOKgMdVi1bFT7zmx1m/MVrs2NN5nkOIVSVn+dLHzpwDvV7zgYk6RqJiZNk8zwF
T+s1yjy8GLCt+0ZWgdfRv5cEow5HxlkT8jM/ryaaWcMUCEuvw3L64k6inZXndkg38CqrDoIio0BW
J2AD5zpZgu1UGQcEUJYtaOL6HaQADU3QMC0dN5lvxcv4fnoaO/R+4T3gow/YWi2OK768BYs3RxRP
pkqeCwCfkgyizJRPulPtt9O/MLtyiI/q8Z8xjl4UFhA6+Gy1S0d+IEO9c3vVYb21goXehF3pQzQ5
j0roYL1qlZAj/ZlnvQpvWHDkEcJSwPtNoN5cQQVaWoLO/GFurtUdlSpjV+hOuL/UY+Ta98Dax8OI
eb3BtA5iyRAdvtXzTyQQe4/0hXPSEu81KFnOJSYlrjGi1YrxJRD8fVVBDlnVNzHIVI2fKanhYlFs
at2PoiDpNIw0ZhlKRmqvUOIYhzGbCApQrJesb6GG4nKkjRhRym5XeHd77nxmKH5fvNZDfbn9x/fa
iSBiVamQTB5D5DflsxPXWbFafUt5hDpCG+qRM0Kt4eDuTCwM9J0IGPYL48Z50zAHLqQgdX4ANZB/
yaf14Wm8GDk9GGD9phgXTONGX7xpLLM6LqmzaguwCYKTjwFdl+TU2d+9AwVQnfV6/D3wyHCBe8PP
lcTmzn2tYA8f9DAgAdnxfiLq3TTWUhQWh9QkEeCY0XO6hALSzizJvpFXb2EWKgWv3MtVZq9mWjGz
dkt/wJrsW8oAYsyQMXwmFSPJCmtetQZh7S6mZThl2wyFR4fmobZ64PHSOtEzS86ob21gK1fa/QzN
kVDR5dqJ0ECX8bZH6BaQIWPnjm4MaVNO/uSQa7/ga2Sr2DbsWeFURJ7KoLEgvQv373wQkEqDMxWB
KsmE5h1IjdRctCybiYhuaawcd4ZQ/xvHd5qmOHuQHXwdfi49+TLVsGL9ulRc5lyO4+NOmhJ1W9yg
ifrz3CPIa1Zsh21/71Ek6tKLOL+JdSVuLhYPdt4EAgVVymIdZOeMFZA/x4F2LhJXbfRPj4i3Bg3p
qAm5lVTy+RUOubywyzGnF+RS0wpg6Pwvn1yaGLFULGJSpj1dY2o6ZSPsho9voB4IgGjoWEUagPih
nMu+0AXMGgo7VZ0iusB42ChQ/izDIbOwcBxcbpVjn5UDEGSK2rzeG2mUOHWGi2qUMIji6HSTkOnW
Utv5zOY4epyR/jaGUz6xcP5zEyRIuefVBeM4np1llSLjYk0/r4hmaS3+YgXIZeS1LA5McBZIg+R/
hIA0XVP1tL0l+eA3QLRg+in94jYzvtB05OJJQZs521q0qU9GDObgKzV2KGvP/Xfw6xsj+NFHgft8
km8Wli7IM/wQOKgOtr8X6RGF1iKiUw3sqoDH/LuGyBqEijJIGIC7sPtIV73iKvDm8hZAwfHpPtVN
+iFoTXlRyV0jdrmW/tnlhkrpevW7rd2oeObYnDktfx8rfCyDdrZu3cfOujEz4GDPPyGpr6D4aWhJ
qNFAyp2yKQOw53OJoIZqlA6cZcH542w65OygH5SfDfAaBR/wZaXLePu0gV8XnbPtkVOAktsCQ/fE
jq9gKe4j0jnxohnGOwLDd4LTQTR2jaG+whRIo9ESK1Hsh19YaFHovic2Jj5nb8JobfeEM6boDHzi
EedARJ6XS3rThiyfOZ6j09g4ZlxRtYFQe7bvJGuEYLtJTv3asE9XEShHiG9MXJclx/THKDWDkHOz
vf2flGmKD9N5Fn5qdSud/iBRcZD1i5hUIwhytdeX5EAqbq6UM1gIG5uILMIGaSUIgMx+3wgiYSfG
ZDT9KkcXctXKWpPFsfHBumwcxSjV5HlvvWzMR+OrCLyGR/EfHxhQ2WO9LGOqQ1yXVPN6uSYHR/lZ
jT8ZYfrjCa3jCM6Wqf27avFXAuT9n37RGmyOKLNhJk31+Q9nZDNUM4nOdQTH0fdDq64FUe79BINo
GWEYXXATZ7PYqCpkXctpYSiYVd3IsfIRho2WAl+89jrMxKGZIJrOESqEBknQ0365BXXSit4IrdgQ
I1rt6wswDYFkk7OiTDtPO8uHFWyY3BcM8PaCfPUK+YfPVexJx3JT7ANyr7AVNyA5/AI1VapwLvOP
WJF3tgJsSVscIotWO7jIOQSGSEAon9lGZQ6MN6j6GAybmlFFakm/evfQR3+vzGzrS+0cPy9D5BFB
Ec2L+g+WYW5etNW74vX9JMcybNwoY2UK6gzJ5RmGCGR0HeGsBK7f47oyl/OvHJSY6ADBXt2gWTbg
nV6n/KUryyYj+48FvSXP8o9KfB1Pa15iAcRNQfVy0JyGETiSzm0ZeTjJNWeLO+7U5zI9AImYAqKc
1VMKs0h8XlDDTWdUGNJbvdtndxOlRwqSepsvyG9RIxGm+I7T3jCgrcOk/Sb/GP748KTVzueByDX2
58SxCeyDrCk4YVe5ApqRyn8qKju4CE3Y3gdQut7GHPBzM/HWEEWPf6qDy3JAqa9tV0TksZMU0SqI
11c8TL65Z50X4Jcda6+Deb+2tnPz1BFfWkJ5ornuH32Bvw2oeXyehdcUhtsGH+QXRsaOxhIFLPXG
AWn+7irnJijyA88IRISe4/S1q7Gu+bPWTU1p25E91Wci2LtKeXf7VTg3yw12+n1w0SmONt4UDgyE
EarGfbUMVnGE1prV7Y5Jtq64ug4iHgdge0vETcCwSmxfYcConCZzIbTM1F0PHRyoakGx4VZSOUqn
TTULSxPojIZou+fzef6WFqjvnFCu6WDGKjgWmvw3h0+OraphW8EKwBkAU6erYxyoNMETATFs98hc
GUE1gqNC77/qwU1GPtEkCXZVgxy61f9IxWCIyZhNytg/FKGaovfb8ptb9kIBPpFfq45F+gDTGGhe
12nStVavr11vf6A2r7q91eh32O6hLeEYetD7qMfqIzvF/rQvCmc4ffxsP21a9RUHTiW9oCL4p/vG
/siPcaUld5hFutpaBN6FLHWpIs5mQLs8WlCh94RxgPGBU4wyuJvhTHtuEplZQt51rKbLeObURgVn
C+JVH+LMYlSgyNEoUl/kwRajWtOMaWB49xVxtKd7+6rOp5jg09ADz0WqWUKmOluIaeTsFHtNdInQ
v7quHJRVq19ngoqbWlW4qShxrBwXd7fxniD7WuHSqvMNWZ1UqWiitg5gW8j1nlbkyGNEWImeCRKd
m1yVanbMxlupt2LVRCv7nkScwKYwnHALwwOislHqeC7oNUXUZkLbwcyssHuKUlhJTW5WLOxZCe6j
EypszdbapT+6kvI9wzabe14elibXbWbNwYfISd74rk55tycJ9HN5l+tS5OOEh7tbSeN2azZUUXIs
WUCOGceZnvC4kBqgWvXo2f+Axqa6QqF/iGKhthgdleHjRygzd12z/FXG30d8jYWJ2XiDfjI1ehja
8sRC