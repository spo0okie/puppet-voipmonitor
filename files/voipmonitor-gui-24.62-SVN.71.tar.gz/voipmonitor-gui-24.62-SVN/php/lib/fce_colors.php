<?php //004d7
if(!extension_loaded('ionCube Loader')){

        $version = explode('.', PHP_VERSION);
        $path = ini_get('extension_dir');

        $arch = php_uname('m');
        $loader_file = "ioncube_loader_lin_".$version[0].".".$version[1].".so";
        if($arch == 'x86_64') {
                $loader_path = "x86_64/$loader_file";
        } else {
                $loader_path = "i686/$loader_file";
        }

        ?>

        <b>VoIPmonitor requires ioncube.com PHP Loader. Follow these installation instructions </b>

        <h3> Debian/Ubuntu or derivates </h3>
        <pre>
apt-get install wget
<?php
        echo "wget http://voipmonitor.org/ioncube/$loader_path -O $path/$loader_file\n";
        echo "echo \"zend_extension = $path/$loader_file\" > /etc/php5/apache2/conf.d/ioncube.ini\n";
        echo "/etc/init.d/apache2 restart\n";

        ?>
        </pre>
        <h3> Centos/Redhat or derivates </h3>
        <pre>
yum install wget
<?php

        echo "wget http://voipmonitor.org/ioncube/$loader_path -O $path/$loader_file\n";
        echo "echo \"zend_extension = $path/$loader_file\" > /etc/php.d/ioncube.ini\n";
        echo "/etc/init.d/httpd restart\n";

        die();
} else {
	print_r('blabla');
}

?>
HR+cPzKW1F+JTQNyCrJfaHze6wsZZjhTGps/oESZMGs6ba1oroBSZwenYf3EJSg0U5MYyvJiTPIb
hH3TvX0AmSdyWmX5VPSm6bUkujAxn4fk88Wl3xZvqvqRY8i4/aX0Cv7gJz+LrpVQGcGEHL+Jq0VT
J/su87k6TEPqFebulurJmMonfXsOokom/Sb3dGnQOrsVTq2ogoO2MkkVdYa/diEcqLN0UUqXxdk0
jrWGGFoZ0mDyPCZihT9Uxf9QC9PzXxGLWCLFgaG0RldtyzMhCoVY1O9CEcDPwrh5+u/4FMbqq3OP
+7MJ/zEtvevWjyA73GCSFQSQj1uaT+H/osFXoJNgURgff2heJwnBbrY9mkkTgWRqSvCt/QEF3ELO
B0pXAPxCsadHTETOPHHPyJt5PBNIg90FPwy2Dvr3LgC/xP+pT748lyBNnYCqcBiDqeuNolSsKX59
imxkCKtOcgAcQ0A1+h4O94xdzKuY73P1qAbaL7nFoWKsRUKuSdGOJuoFCs0MI2MJLwO8ik+5vTIM
Le5rs+PrsbCbKsed0n7Ixk5ABIU1gkv7Ig+Fic4nIvHCUxXIwbLD2zwFg8nx5hzLCaZid076ySuX
cCxy/oMGDc6l/XEyvi2PPgSqD7F6h9s2wB0pbYPVbrE2nTmDWy3ehaLLZZqbNUj6h51YGJejhc6C
zT4FNUr1hjhuprpXDFl7zeoHkuZiB3QCB9EABovxzdZ/3QHHkhy9BwZR3GHb6rabHPWiNzPtCyhz
VhfCn6BCSyIVtVjr4XwOC/udQjONYhLG6MPDbfacBMPgdZaHe3gcXVxvjKmVYGoECXRPfHcmZ6L3
otdr1itrzBWp7xc4lWjKOWZNO9jyybn+GMoajf5M7Owli+TpPJLEYSZ3NXc9CbU38PQ16E1iTt8t
ABUnaOUS+ao3ArI7H2CBBJ0OjiewB05JqvhC1CR0Byude7Tuv3l2VCK8xGJm8rSvIZXJu1udLaRE
4bTSyFnhknXzN9dMgVRtVSqoakOgteOBThwi1tCYlszyB5VX0thMJjG2m72Z0Y2zKPi92MPGkxsq
z1dKBV/xTgrGTry+e/VuKF+2dEAM3RF2EuVslrj6Djp71pQKoxoZNrh8pYrSKNkEs5sdatoWAy4m
IGi5K7WEUJKdU5mAeAuN2Itrjmenqhkguq8v9UUyHyRFnpOWwYVqh+vKfz0r+MMkOfRxlOrSkH8Q
sL1OtwmWkTdV0ZNON04aa2ncuzo94U10a9E9XY8QUhm6jE12snPWsSg7GR+4QDpkl/gj7gWXaCog
Hc4cE/A7NTphfuuGTwd7ivZbuBsETacwPdqY18aE6JBNM8OQG/+TCgrDE/wlx2KEFl/C2B3LBg2B
Qws2i7WZhz/sVx7KYM6UVDIAEWj6056PEIlD9Q60JJHZ6IXO8/WFpCYCc0TW5qZdefu0LUlurVEC
jPU3G0iCCtybm20ufsMBr0f0Ywes5QiSEA+2jfVuT4UKi0wWI/L+a9CV49PC1O0d7I/I6CtnDlI5
f3BXXliMtmW9pAhkqMD7ZG/sMRiVD6osMW2A1ZyuowFGYDaRVj8vcqSStt+dmx4XEyUE+4cBPYRi
kGTupjxlrzLaOs5WZIZrPyAm0GhBx0no/rVmh49frFuxMrXIBZaA4d9O7KAvGkXmUTPwJ9LDEI7M
TSxOE8NwSa5AmqvxUACXe206hIg9nlzm9FeHIMVKReX4EQTti86/Q/Prlx+guzVFejXu1FibZK34
TGD1j+JmaOK2VsDkjf8YGbBRgLrJAVcm4AlAtVTnQfiCXnHRH38pUs3rIUosvN32xg+xTcK780m0
a/203UUhLZgVOmKbJegZCAdUaZYMYnkmua4N30OjvNGRCt6o/nLSIajBFLkCqVBh4SqNh3VvwnOR
5BnUPNJ0nCUdrqmaUiZIRVBHduzKEGBYmu2xlFIO3cj9N22tySzP/2sxRyqKXn+GjWLIi0U5i2TR
X/pw7qSRzYjQKBGNcM1vLRgqaCvVNwV7ujVswArF+w+lRQI6SvsaPMpT+8UvNSqiWw18J4rOdU+7
rvG9M6AE22zMakDP8/YEM3TRBaqznUWq5eaahc6MWxnh+ZfyiwNNJMU7x61ErlVIT/+JMOyfwnqg
G8bFvgvNeLFMbNaCsuie2sT60i6eqpyIoXXpZ1Z07JUTEok81OCByKKajSJwgBBlMERaCY0vCUd0
UxHR7BbpAyu5emjl3NX+V0NUiPkNDPtVSjG19b7e0ykOiBwpZFMwLOhQ6xlXzLmMAAHDxJL76rim
WFtmn6N3qIMrqoexa5sKmb4EZSURGYQ3L2m2IetpzS1xBJDkzPEOw8InhBHomRH19yGqCb6ZeBDv
Pri+6GgG4SriHdI+lluuULH44/WLHYYb1zBIZD4eoT98OLLElJ589m65ccy+fLZwh9qFx1mFUCgk
U5ydxM14xkdKiR8grLQup5VE/wW9/oJbnZRmz6H+7DFVnV3Qz5Zzh7D3EtJcEyeW9bUbnkbnJ8GJ
rDh+ZeqNU2A19X7pJdbp2kSImZ4G+xcLHPGNDzAaTcScwkiTYL/f+TW2lZY+6yG6hKKsJN7WNPjd
4mB8JR6vEM++IMeq7+Znf7NLKXS2iL/oy7GBYhulMjTeD7Jtmtz0UAFfulJk09vooQW33t0hM0Zw
dABI5zvUQhnve/+YB8PAXENROxtenpOeiEe3wlRqiTLlRdkboGZiE6t0yK+Y2gY18cXEq2eprUco
sL7gOXp1kGV1+fmQS7OciMZTfMEE7wUjbaxVQUNUuRF/4YfCi+AIyGwMvc+xYtq89Yd/u1uZsl3b
niDbLrzeIWKrrO61BPS738AK5XiAaGIG49w5osLBNZ4tt+26UdZPxM6tMl0/mpeGH2IYME9pVxZ7
ZLqrIfMA3SUSkz6i/3itZqOGUR3tTJDh6Yp48wK2caPXkIJt3v00rVvFceoGAWRb7zRvrFafVcy8
QQhsXxcKUrAOBAYJ98zlCbL7HfrMdfs+7FDeXOf1r22VUKclXThp1J/u3Nte2FVZ4iTVAmzBW8K0
SiVaBJbO2WBNv4D3Y7EX2+V40GJXWC3d20f29JN4rnjyZuSDRrO39/xiutTQwBI4xJ/w9cTprbXL
z1MRJOwyzzzvXKfwwcl4muC2QxAtHF/gbdZHHPMQxm5LsLcv/pbfa1mGw9JhN7u82OKjlZgFRF/m
lqMTzqzTBoYNN1VHmHpS7wCqZRYOBpw4UdR3LT3zxHw10SDDKX4En29Flra3Rh7NoeyefNyeLn07
AmDcGBGE2OTl7p0Ef4s2qWxzp0aHsL7HNU82aM7ZsmYQqqi1xCyTg1zfbY5etLyEuZ0j3mXkR9Sw
ihhybTH9whmETUUs/5Cvc7nho2EKONWcMzqZtRBOLo3GTvWjQuPxgJ90Sc85gCvOAe4mvbQ6jDUS
gUg8gRAU6BgnkClR+EdYMFYDYGUWQEkzZvbuC/KZrP/o8kBPpAItaGOfL25SY/izIeH1//imxiyE
OCmAompTxDa3fBfAqeKqTTepxY89iUIalonPpxQfpktlHftFVkIhgZ+k8EwphOTAcPjJwpHowu12
tRwmrTKmnVnFFx8PaeEhvAcVgcRdDT8Nj3C+NqAdQp1WhgWTWPJo2pqLqyy3lIZOrsTu8yXVFUSQ
36FOZuHsJS486LeUk9D74KTfcEaJfTUDWb5zBR5k4SgXlMnqimAQLuXIAnu08XnCs9LO2tkR/tNN
BxFwIbrSloFN78UEpiU5RP7QID3id+zjJ/bf0IDs8aQjH1xikcC5SswUgrcrN42tE0lO7+zN5JPk
6j433+DICvpeDXQ9GUR+dBCOpPJ7rdR/RGDYpx3xYs6xXpeinW5E5zC19iFYuUcGT1WSOuTeL/lK
gV2GDQZ5gqh2VTq/yX3JQm/PfOhHKMP8AnXQBSDq9/a4U3CRcEl1UT+FfZObbdfE2tzsNILUconj
b1e2b3sa/B7xJKG0YnEL9srV3dijBM2gLknfSfT/UpsNKY2rMutVYNmlTHVwTsDq6jYW52ag40RE
7b5skrL4+89TUGkCujg8GNmjMN8v/BU4gGcYSRhqQkZKbJ6YMDkoDyeGWwB52G0sRRGcqk27vF7O
bVjA9g4IYfoRXX6/V4KO9F68by6fsrpAKJjKubXGlY/Dy7ITUXnXQwEg/oyMElH1PVTE7Vzkb2sE
Ad2Xgq+cnJ1Ty1uv0XMUNgAgPC2B/jFwQahRxTKdvGtj0bh7v1CtFtS1Zluox7WuDdOPxPTMqMAc
DOQJrCBwhTG2P1it1kmsPdxGJuzHgzONlCciltjR4p/TPZzD2E1+ANsBnrQtzplIkE3lJnx7dEM+
KKJktp7KFoenESWmDNJColM9xPLFfttdwnpEePjG2M+udGEE4xDHbaYcJ7ZG+fWB8BLYuhIcryev
HtSE1+I+urhI7J4LgCuAFnaSgSaSuY/3rDm6JJl/5jNWlY4cH4ad/8FfW20I6g/9nBj3eFMCJf0o
ClBGplig3EHEpcPgw9D71/RO8K+2b7u9/o9OPjdRq6B1jWDOaeZ9zeqCIZPx1mXQvtP47gfSTugT
UKaXd5UwnKC3NS9AD1ivp+X+4cT6FPsMEjuvHBwPrI0aIfRu5kzBzkROJF7n42edNj0zd9rYUln3
g7v4q6AgRO+SQLW9p+eskz1n1VprA77z1OKnC9kgfO4sPw9tuqH9NEyqAbWCd0OQn4t9bGR9Pdse
HSN5n7W2Z0fFlFxsORhBrnVkGpVuat+Q0TRfFXLLsaaXxCrGCXEes8ok9jQ/xSObZjbeXA9XHiSb
Lq1wo+V0w8+AtA9f6VRX3/hdZTv45lLM76UdVU/ZNEu5tT3wHmsdw6KiIVMNbpJI3J+5tM//TcgP
77mcm4LlyC14I2KqSYmPu+ej8HzCX6YLlNXLSxF1BPUV7GBPcuz4ghz1WMFZ3AAajojUcFLp8LYg
RbGuMpsmwMx1HawtU51mciqrvh/NCZ4r8jzlPEeR8BLVM3835oEjA4Emc+He+45LH+IgI6Wihlj5
YLh3yK7OHonYQrCZAtEOKaqepGaq/e20eKjf/HdyTmlEQH+wTvV6B5+JdPjtSCAomvMsv481VFWY
f5xdxle35/Zan9+TiYrX12wx6d2dVYC7IA9+y+qU9SKfrgsslmDprXn9w/U9oIehmIi6oHh5oTFo
mYtKu1naC6rZqrtzwgiqpE2FtbeDatXiVn0lkrWnyRQdJjnz7kWBImjQdwmQ2vR99Y4Tu/wzoWCe
ch4FoWfbDsoRugsnxVG1iDwCYFyzZmOcEzSYOS0qLHcXMq9wOqiPAgd4vn2Gfz71ckjblNOY+pYh
EWziGWu3EUCRUivjZg26rzCDHBURay61qA6kQgxV0vSTYd9S7H/0VmiiAS52NzSscC+eGd4DMGvA
dg6K2yj0ZMH7vHHZs+GB5A3eu4wy6TM/CaSsFqMj0QrtSR21dBpazWNRxWyEQHmZ1HroBrLE7Py0
yZRYUKs/MfeWGkVwX1FTcfZ7iO5thBaLV1KIkdGWAl5J7K6Fho0NOu3gL5k0PKM6jM6z4b/s4h8E
QkA1riOC5Yym3BWnkHu7zAfPA1RCRT1KmZqYO6EtUO4S8G==