<?php //004d7
if(!extension_loaded('ionCube Loader')){

        $version = explode('.', PHP_VERSION);
        $path = ini_get('extension_dir');

        $arch = php_uname('m');
        $loader_file = "ioncube_loader_lin_".$version[0].".".$version[1].".so";
        if($arch == 'x86_64') {
                $loader_path = "x86_64/$loader_file";
        } else {
                $loader_path = "i686/$loader_file";
        }

        ?>

        <b>VoIPmonitor requires ioncube.com PHP Loader. Follow these installation instructions </b>

        <h3> Debian/Ubuntu or derivates </h3>
        <pre>
apt-get install wget
<?php
        echo "wget http://voipmonitor.org/ioncube/$loader_path -O $path/$loader_file\n";
        echo "echo \"zend_extension = $path/$loader_file\" > /etc/php5/apache2/conf.d/ioncube.ini\n";
        echo "/etc/init.d/apache2 restart\n";

        ?>
        </pre>
        <h3> Centos/Redhat or derivates </h3>
        <pre>
yum install wget
<?php

        echo "wget http://voipmonitor.org/ioncube/$loader_path -O $path/$loader_file\n";
        echo "echo \"zend_extension = $path/$loader_file\" > /etc/php.d/ioncube.ini\n";
        echo "/etc/init.d/httpd restart\n";

        die();
} else {
	print_r('blabla');
}

?>
HR+cPxoproVWA2m8gNP21Cvm8ioLICIu7we+2yfMP2WHprfZWg1dVl8vems0SJERlvtH6xPT6lTy
Chb/2ohCZ+Y9k9nWgxpRyEYyIU0dCht4O+6sdRa2+waIYmMPGhnHTkZxQkQaAAG7vQw2tJ+/RSZL
SionbMH4rMqMG3+FnDklk+5VpTHgGfrFY3ygIyp/3l6hiO4J4ncZNXMWXEbyWvcGPGQddL2r2LAc
IBQO2jkaFlKB5O7vCdy7HiVvJS2TfBi1cuSW45aoStKPDNjfz9xXLcY6XzoxU+0dQf14JU9rzYNU
+MSWSXjiB/1oSdsZEqXlupbiXAZTQUYNtth2KTeRBY7JsAXYbPUSOONYVuC4Xa8j8tqd4e1B0ni8
9b9xSsUjQeMRRqhsArjdjjwQsQ6/WyiQvKcR/IU4cxsAK3B9GMdVSSPI6w5VMlEar1ABLs74seOe
gtr9YwKczbIFKa+byqsmdRk0/FrhUv1WiMQv3Re5k+zZ/VlHlmb8L5Avm2g2k5YOWZICvStLYZXh
NtrrQvAWExta9fd+B29A+8SOHkKqOQZzOPXrN0vBImtNd9jgCCe493hzkuc0GwbURTp7vzMwdR2d
E5zke+u4VZ8EN0Pcj7Ft9k+Pnk264wvaJC3k36vrk3azRBeBrCWGOrXQo7EaXqbjeVpA3k6eTaR6
sO55CbNbmN+Kv3VcK3a0g4btHz2uE7sppFfQYvFi8YLqJ4cMv0ngVHoYPL16MqFNf8J5kN6JjPfo
JVOoFgD5sEs2iM2WWZD5sKNXstFK73w0OkNYIOZ4kBEW9Lnc9HSkigujwqQToHzCCyBSUmqbXs4Z
z9Zz+Hl+vBwJkOqkXiHuBd3ST7fZWTqCIxzctyBr9tM2DOrCpcyvZ+iuYjN/OKJGycvsUN7PZHVC
wCDy0Z+OeTgycszcZmIzEkpYieeWcoyeVJA4A8XEQBcQmqVxaaCWCGEv8j/OWQQ5PHncXHsPdbFs
hhEJR4usiyoAh9HeS+OVr4HBXaHaX2MpGLHwK0tYTGou/caTq4ZZJCaxDjAFsFNzEc7DBzO//uQN
3n4X2w96/oHPbjg3+ygOkZWhuckCrIwtqwqnMMWOGTqsSk4ay1h+kGtkZMGwW4VvVzGYUdc0Dlyc
Ioo4asQpUd2/MEQZYQOHoyolEWNRufiJeNhS4yTJBqsZrOM5aDjyAUjHtbFZs/nPReRA+riLCWu7
l6DgxWUYOIaj08+YbRwjYd8iu6pymC27ZSegO56/XJlO1UpEok+Cq5lnMqNA3W1aNlvNPepvyZqz
WJ5VzX/x189TQ12n92PELznt9qUH/af167V2F/r68YIXBC6Cf4y2Ze5rbi24K12ljRO146MJmMRO
WWdDv7qt3/7JBuhIceMZgmxcUT/bNz+Q6NhnDwxevDuGTXBsoab4ijQujYtSwu8rUuvtlT3NaH3M
A6/k0BVVjO4+Wn55yVXODRonMPl0RvHjO/Zu0GsSGTWtruX7wLMSCL+y2ahtznzmJ3WExiHyGU5A
63jJOvlP8xu8bNjyTD0mtJ2S5WsHsadd/EWZ1dauv8ab933CuUsxxkY6Qy/A+eGnclCJJA1zV1NR
LgmZIHjv0klKolGsel9pUSO0MTb8W6asekIf4trnCd5fK3iq5R/X41Y6ZEpWoI1RdvqQSvf8YMcR
1nMaogfVJF1pR8alS22vmK0+Riwr206NcDuPW7WWIF/hHq6fqg63SWnniJAPtcwZjxZLcoFUaaWw
2010LwPs8s4D3FzVX13XW92B/oRxKnON+H+/9EpGW960QqOX1enaGdEnAFmWtH9yAJ6CLR2LAL04
+N8snl+x4EiANb0FHT4d6tGwT/lltvB+8NjpSQv+Vp4kr8RsQPkE5ckkBIaTub7hVi/KVDaiQLcT
dfnZAux8/2WAlAhdmcXdwWiioRGhqNoLxOIZEWQtTmAFZO5TpGXQj3sb5SSwAoNlMjuXcwGwgQIe
baNwbReFw+ztrF2nC+i/bPtEOsHtNGfylTCtVL/44iCgET0zR0P59jCTRUZllSW74WDQo2jGp/Vk
7XuZYAclHfuOVkjHOjv63idftThelNi8dy3vXToESupfGwzN2db8Y+TVpYANKcLcaxY/VsacuxRs
s6IVfXV/9RFVRNUl+yT53Kt6RHBtJ33c/MZBhhVcYA+Sz3t/Z6+UrDmO5TA1b2K/uTZq7EcJ+bW+
UvtsxWyxpOHkbMSROZVybpyk3WQcdNzrydj4UqqwVtpjA83344F7HpcXjHR7mldJO1gZ9pIB+W0X
3irxOckQvno8unjpuVh0//1NWpqftca+23XiL1J+lyx2u9fSzbiDCM5vxQj3/c4fopMqnP3+oFSp
oPqwHingcImOdlijhaDgS2eB0oeBKTTL6fL1sOkeaiaPgGpsn2MTeweZCFYSPMz3cyJzAPdtcfl0
sAbZJocw7hhv8lqajIfUA+t4Q4IgbgReJp4edGp6ndxF9pBtw+7uEMyQ2RDTMfjgBPof3abOQzoL
iTYF/FoVdNvKytMaYw14rd2TyJhN95icIM3kPlVOBEOsgIPUVPCwyV77kfS7IEktMu8X8ues1g0A
syI/4QUk+QhRYS5IIPvFB6qaq0Xzv21svW32MoGgW7juHEpjPo9j3OsH+kp3LtsUjJel6kYxG6EI
Xk9+YvvGClyQ0qa6sbAvpo7XP6bVOAWczkyup5q2OOCkyUXnU0M4Zj5s6uJ6kjRgVntKuEQ2p1ek
ztXLCHqhZ3GOMPRgH/k2iyoEsAYCgHTNoyT7GiQ1loLvHEAajDEoSAp5ZBSRH/AV7Tglpme9DL7v
SuUtwcMl8GExSjmRoHzdRsLgmB8+7HruRr+mz3UPeJt1TWIeGus6JTN79IxB4/BGc2xnqz2ezKF5
edb8lmrlGL9QV7iuEL7lcStYLr06aOh2qx23ccg8zwMCuM6b4nqJs/1p5Bptay3ZB3IzFxZ55i9k
R86XrIeKkkumIVpNCV0gTPsHSx9bFOVms0aawckWkWRd6yi9MXfgjwQrO3LUXHi7zXoagQKp6Wnp
C8e02i8I7o9Lb+By/FRagmewDN/HdC0al8cNENIyw1JM7CfSSrky5WiwbsAF7fD+9rQeqWgYpBG9
SkdSauTnOWmH7O5wzzdZgBH4x+eOXVa+UYNoEHpLUwi5eNwrGSfTmR61fooAn00s6KN5ssklMw6d
xHVAy09NYJ6xFvcdPbnaYfdm6hPD2Fyb4KgKoJqGGKcA0efwpJDNGH3c3LBV4H/5OT08buTWyli7
GNl/1pQlkUwdtQ3njnul4FCKpdWPqd5lrTQP1k05MSKo2Q3y8WlYVOAOn3e39kYccXvdTSYEz1+S
AN2Vxely9C0aU0pwJcQAIvEJFgUpANKT7oE/bveU52BsAi13IlKCiLCa8YY6h+sGGYGRnkSvaMIz
UZFSJ1g74M5GGKXYBhiiqlEBBjyBnP326HloMSoSb+fGt9fZPntSzJkN5jQp/b448vRNGQTUu0d/
pcUTql7exnsrEMW7pgh9aZDVIET1c7DuK9lNijVEuJ9gfRGbAjstpjIvj/+yTsPN/X5GKmOda0jk
nE85IGvE0I77Gitq52CiC0Psob5Ha8dyELm7NHlorEcIoZsuBxNakpjq1twmh3tfXwyw3KgXMGum
Re7g2NTq7MDTP2S9Litb79KbF+uCnh5hC2hZN7X93jikrdLKb4lUaPEkjKfDvRfIiHnA9boyevfS
eQ2TUUCTqCHcqchplIuGpgVjf2iX07ZK10ZzdAKVuRIeWgIdap+hycfGob5weqt3Q+89OuZ1JeY0
RRXLDXoiTTYaIsqKHKWGDbtWxz/H/8v+3Jzl1YXksFIefjK9mXWhvfKL/+CK2TtlFuEQNXI3Snuf
uM/EIVoCvWD99AUDXgHr7DRmO8DwtF6Tw0Xmh78tkKs8jq/O3zBuo+hlkXgLFc+vxq+/kqhHScBa
hF9Wh5MMA3UpQO7BDJiILKP5woZNXnmgpsyu4tf1rj7Tj/abS8nE2Dq+SxZW28CePdNIR4RQqcji
7R/j+y6XEmCdBcKxzl8bg3TO4IU3rS9r9uh3NSg/ewGoPiUX3s8nsFZFvEhp/Bu8gXTTbxoGnbiO
UPcem4xxio3pSlV0luxh+bajJybNujr7IzjoTrk/J/RYmlEF5Gb+RYZarcxgaXt7nZVBB9P5+RBQ
OxBZwO4Z3cVnMyII1AkPG7VE8tOIWn5Py5zleWKZ6B/V/plb2jxw/hBKILfbC/JgfsaTIcCn7O/G
K9TWuPfinnnpo+fn593Dvp5l+goIXb1eEHPVLBHzGSF3wncxfDoadvhNvlcp40V2MYX8WRFGEqJl
f15y27WIhg5PMAlWjv8aU4/5Za0GoVifZwehZNlCb+xehaEJJiGOMmd0I/Ig2phZkp5+2eZcaoco
D5TeU/mED9I1RpFbGhv27NB6OnBCvobtBrv+IyBFkib4OG6q8EUjRrYwdwwgPzeDgrzuOE0rr5Oq
KiSZMrm0/E5ZLVhkX/qnhfb7tu2RzqdFpwvpqSNYlKzSMQLAWX7/Rh/dYc4jG8LBhWuujHU7a3U2
szgjnP8CYNYS76lDPh1h/vbU0XHYPcVPbIHZwqwA0Q2VMPh0u5+NZZEXN2V/sctin6CrozGamjug
mYvAzlTBAPraSPShEBoGPtZTcJAKjAvRiDK/2aRhnaM5djt+AnWe6/hqZ64caMQd8uZKb4Lqbi+g
0xgajFDH5OX3Xuc4yyiHqfmfihBGOFoOXyVlyEX1dXbll5x5EcNwg/wo4lsXlgqxZh5j0rjVuqSz
pK0dWKh+GBooPakbbqj+0KqlXymuBSDBp6HPBMCHAUx9Nx0fH8Go37jubKJmbnGz4g1nReVMw7/B
jXbigzm18vKNE29YfdncbD2tRXqH+wL5hNmKXIpppdAV8YwPKvR/O+J2e8YgcFiEt69kwCCHKlLx
aoOvAk9UZ6xOFh/yEYanQWTYgYJlYo9774DdfXAr7+0Elh85KPjfLdMzMFq3Xeu6CCyv+Fu04/Je
1qw0YlqobBTivi9QHNyB4Q2NFnZGeCXozTJ/64JmD6VabztjhfhKAiuuN7Dd2GJO7FI02d8svt9n
IzN+IRrhK/Y/8eSNiBTU4cK0L5uhMinPfHFDrCoBjJDA7DO/d30iJNWl5AKIso/g5yn/x7BUCjGQ
fyJE7AmkI2VdHUTQWEvGxA7KJC4cEjDvBVKrKUFk59EKQN2fXAFrkLHn/pvXihlKc1wIJlAW7IXv
LDBFjR1MOqwongIsNRDDfqS2a1Clu7J1SvJ5uFdQQuTrsSadPzFmxrHzwyBLQfmwQymLFb9M+FZg
jKYWIjTrA/xcmqCNp9mY/5+rOJ31Rsb99Qq1bC9XZXrD6qyPACiadgJ8hnoZFkWCm9QX+6C84EqU
tgQWWj2uDk6+faAtHqxV+PISzRdzprVgLwnVzNhE5gSaDFHBFPT8iK/aQFNKRJZIIpeEOTr28st5
ehv3I0Ze3wOBL/yF+uDGd67fEXL3coYk26xtdpjuiyBvLfg8yHgnrw97DGQY34NyNH7Qb2CrBIxd
mCXWg1yUIfhksYkqwqfJChbdC52UQq3Pcp1GPl486oFxxY3k49uP4ARuamOVwyv7KC9suEM2fCui
0tPl6fpIj+Ucf1m5N2AoctueH4e1T6fy0zoRRLbohKXwBTuVLIXHnRMAuqUhTfr21OxfIDadUVUl
T7+BnUmaHru+Byh7nxCRSomGLgugAsn0TnzzpRwwdG7WM8XDNvEdY29+v5L5+J+YOgnImbbr4354
c6LN7HImLwQ0tcfOG7RTrseB00SaNN5v3ke1NTHyL2OAfa4dltEOY5SoQKVef8Md+zdjLgORTULm
LMEpDLZW1OP4f1SoHSwzRKOAN8mRR+/AKdMfQDDNP4sYwbGwku7qQA1gUo5ZJZNkNSpP6ad8UG3F
MX2VDsWuvXkyYq95Tn4EfLPle5g4gWQL6Qw5q5Jcyozs265iWAMn9TAdZOxzTmlY4lbwPWNRvIIM
MPVdKxsc1VveI20KPhviaSvccvDRFiLNHh5e1lStgRSjFp44JcUndb6BEWjDEJWZqFbPfKK0T/hM
cDLEJSaII8FYURgq61U8bV9h0KmFoyzkQwUhySbvK3akWLUokufBeaRpzqPGy0xyR0iSyChDzCwa
gVWPxFswTLJa9tY5WpIh8ouRmIZAE83x+FLYZBwsvYUugdv8LD9abf2xoVpqUCik6BMyQWJQIHuM
uXsoemi92SnMBUqVf326JsQbA8UvTPuu/uKs7zK4iAqXArkunn7HdLFvfMD0n7s7maIBjBQ3kRHi
uyzrGy2pkqd2LtnI7Qh4kVQ/dQQ8by1I5qsjsfrjXWzgwlrFjfYHS+HT+1v1uYQakAvKvWNncNUk
uF71OKtQr32hYWK5LbQ9G3PyoQ6vGlqi5GrurzcbWlylebutoP1sSzoLy6gvk8R8NtZC5fUVeZ2m
+vC1j5GBVkjwTpfRxwYGpF3AUx2H+wcJmmO874X1XSa0Ujcy40fAI1xLwVRm1UkG4G0eCOAJFdIo
quYHHeNA3TTBdZ0f5iveSvRYgCVLN23q6Egr+8JqDIH2wvCTaWuBaLg37UVwqSgnRXY3WXa3mGgw
cV47xhKwzH3V9tE/B+T4VAxAjw8INsFPwsscZJL7W+MbXldmyr4PtewGzsKfRcGCiu7/ZXisFNNS
jDwgmZAXqk6K3O5bkTPAHaoTyMOt/o883vNNQ5eTc+pD7PJ0yUjr4hneE8pqXBPGpiMT/FM7/Xt0
YX+AjX8R54w8PLxDqGwF21YXUUfAnarWMI6/Pdws/ctCCVT92YiQ3ZEJzhKsTKU4gZtZ3u1y4EpE
tGILVDcL7DQxssJ2awXa0cH/HpG/OPIi29rs9B8fJJjrXDbfokB6LgpwiVSu3g22ta0gS6Li0fui
FKScZ+jN0tUZAZAtoKM7b3CCRLUY5p6ouy4/QSyuFWYhssQkyIs0mvvHDrkqTBSUgjD9mmsvrObu
jxLv7IkEU1W47il04gzlo2v6JmS7ydR9uXwHozlJTPWuYSOKchWGPij3Wky6s0E4nxgSZuMlE7JD
0753Ts3zztruNVvijoWDTWc/kapCgTVVmh8=