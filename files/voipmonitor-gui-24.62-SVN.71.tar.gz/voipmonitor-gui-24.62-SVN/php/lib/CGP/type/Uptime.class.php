<?php //004d7
if(!extension_loaded('ionCube Loader')){

        $version = explode('.', PHP_VERSION);
        $path = ini_get('extension_dir');

        $arch = php_uname('m');
        $loader_file = "ioncube_loader_lin_".$version[0].".".$version[1].".so";
        if($arch == 'x86_64') {
                $loader_path = "x86_64/$loader_file";
        } else {
                $loader_path = "i686/$loader_file";
        }

        ?>

        <b>VoIPmonitor requires ioncube.com PHP Loader. Follow these installation instructions </b>

        <h3> Debian/Ubuntu or derivates </h3>
        <pre>
apt-get install wget
<?php
        echo "wget http://voipmonitor.org/ioncube/$loader_path -O $path/$loader_file\n";
        echo "echo \"zend_extension = $path/$loader_file\" > /etc/php5/apache2/conf.d/ioncube.ini\n";
        echo "/etc/init.d/apache2 restart\n";

        ?>
        </pre>
        <h3> Centos/Redhat or derivates </h3>
        <pre>
yum install wget
<?php

        echo "wget http://voipmonitor.org/ioncube/$loader_path -O $path/$loader_file\n";
        echo "echo \"zend_extension = $path/$loader_file\" > /etc/php.d/ioncube.ini\n";
        echo "/etc/init.d/httpd restart\n";

        die();
} else {
	print_r('blabla');
}

?>
HR+cPqzJuqxD2zXXt9TsRQGl0NRT8SAcAt7V85M8F//XCXZMjNoouRPL1zweG+WDpMUBMDQk7wJu
1AMBrfgq6dnuvPIq9uZ0aS4FfyMsq4ERB71k6MoSkJOdGLsHf+M53abtYEyJ4z8pp8yzPaZZNqFJ
SR+HjuGtSJNUqGlRaVBuvNgj7kP6q43xkc1uwgaAGRwXXs5sL8Omx588NIW4ZPkAWBHKN+mWM7Tt
cnWWKyXTuTX/AOWG3mhOa4sqGdE5ZmVwlFPOZoE/pvK8Y5ezRNw23hLjN96UQHIQ/OMmcRsJKbvI
t3hUYTovcibs/Njx5irGd9ITHh+KU9VVUi9HsXkq2IuXqzYeOfMNdFk5kp2Xa8mneFioHzBlWyKc
EH1b15mQoNpNZSgXCGSY1TfGqiAvX3lwBZM4Aj5K2ctrpkwL3OxBCZLLosBBv/84Owg6zyacJpLF
NePjKxi1bDLWEkO+UlyRC3+XcWgVJEnyydsnCtfi6CoyrDBKAQevnwV2CLyHKGLWJ16VHNK7MPOD
JuDFIUEgkmfUllYNGbAmhWH2Je973xhNl966Q2iGUEs0/qNLBxTdv9z+T2dUo0kq0gUemZMKMe9Z
FHEzBzZl+M7Pp5RqmBVZN82WJ6bWokrjotaBzhfWsFimvk9lKXR3fX2L7c0HX+lSxg74/JqNouTc
aYqpbvAyTjLBKY05nWwx71xHJanXaqyZ2PGs3hnKSXywkWOKqxpqZcsgEMxYZqEQDfLcqYmR3uU6
IL9z3TGruqDE5eSTSTBgWX9N5sNGkqxN6GrNh+ajoFkRvBJKBEMRwcAannD4MXS10zIlwoDiSRfS
SfQBSPJ+OLGcRhYMFxgyYRZ5p8Dpe6hArSENReQbJOgrYLjUCtGC3tZtNJtYA9PuBGq9GZ5Ni5Ug
q04Nizi2D9q+2UdhnVQIKWniaNZt7XkiiorT5Eg4BPORJF58ybD2hyJreQ+MIC1cjyzMUgVzl/M8
FWwlnq5evcXpRo4skv/woWrKafi3vUZJzW5+PJkkKS+ro+QSFG2SoJeQVv2wp7lWO2DXyp3+6zHe
Df4clHEVWL6pCKGaEAQTjsugdX1xzu/4dU8dFGJ3Af5hJZlezd2c5/Khh0L3vZhnguoM7zP4jIpn
MeMHpvK0mYBSxEcR2v0kWNMJHQrjjlAL7sPmXtFjdS7Ua7Bri7DkU73TfcsusOh5SI/iDolfMbK+
5R2eDlJa+5qeKjwMicis2RIJXyKa0AXncqQtLHWTkV/gh2uUoCWkUzYvAh9BMhB0uVg8ud13uDYT
KVlBkbHJEpjacEXEM27zzIiA8LH+I8hbiarINxiVMv+X38ob1eqJZGUGXHZCVCjmjNcUSLj8hQsw
WyKvr13PDkRtv0FulB6uwlLS/ctjXE/mvXWtwKVouQ8MR9hn8dnRqXEr4w84xkrHmuoxmoLX41cq
cIJZVMNPJCsRpCfF0SwW/3AIb3Vo5vCRkv8LAvZKqqv4ZjTMbERJEW8xLTDbQ5cf2BoWixvS1xK2
epUZ3TegkvXEPXAXmsrRdfdBOQir/Q8+XN59WXgv5gDVYygeEUEih5xENW5hsTCJQZwDu4Qo9eOA
tWkrDzzdBbiVpcy1YbDkRY++EgZSxN5Sc+cwSJ+QdR4jAbBm5/eWj5Z2LdX4YMyYBtbfAORlqblN
zLfX259E70oYfnz2qhe7Kc4Sy+GUWpKcEoizOsMIsG0fZhlLqotsyYsNnmOUHmofjzO/xlBz1bk4
9YWGsqdY2b+nlCpLC7FYRkh3LGf1LhLF4cClnVTWKtfdqYANTb+8cjrWI+QcyPww/Few4zLj+VZm
k0bLgMhIYm9t7pq3PnhwKt/ykomQI4L1I7ZVKdcAE6jodHUy0rQEkje7dIQeBdQUoDpJjf8I1hqW
yraBDUVAuztdaYtqOIOfZPeFJAxN0qcxx94TSv0sEgrK24r9vYogB5VJ5eZgmw9IpbkJVUWIfi63
CYC6Fa7S/InB3SaOa009Rh4vUyaTTsGmbF9WfUhmKeqhYwDSIX1XBKPt3zP3+rSNIy6aEPS7bEA5
DVPu+dqjZmNgzmriaVK9zkax8jtX++0ru66pG0gUYraR+uVpekNdaw83i/43qLGEqrdwUbHLJF+Q
Dy2i30tWG/pIX/kg0PWnOEVAeNfX9m054Mtdv5cMnnj1WF1qRzoFletj5JLjTAnGReX7zStXQ2tS
xRi7559e0cNw9AA/GdchXYgecPGSm9R5S1O/+dvuwSgt/ovRLqSqKvACzSl9nX+JsS5Ojd/UrgIk
NKndmyEsqadbnTST1espl5DVO6F8bPHag77sgZrgFq7+oO1eC0DGEolmJxdemeiFyZzQbUGAg5Lq
55ez15IEDcCNTBEPHvwuQJ1S7RHq4OcrjsI2noBxpwjqg29K5B0QX79EqCQ/YNSwQsdI6RQ9BeTM
aS472j5X/ndisBESomLNfaCB6JKuDKaI77irGwBK70wrvR15hSaAz8F+3xNRIerKFTjONDlkPY1O
xkmZcvxXrLiai8F6i6sK1WeV0xBn3oDYtqe0qow4Hx6O5L01B7AL+KoxbAqd3WGUlHlTfQdHDqWp
xvDe4TRdOxKzUHCs/y7tUwTcbPkg+xzQ9Aa3tPSU1tjEN6LWUau8Bg9x7YudVVXd9sR9XObALD6M
tdkWcgLSyDJmW+WKDYO0vaJ4dsFE0G3EWbIydw/XrOGpQvYKJlLAatRyd5bSLbU+1W7Bi77MfV/x
H2zmLnw5z50tDnuwVDVVx4R51hIrqOuVcfkZlapZjTU4Yoiz6kguMNwSBPoBm/bP/YCCxPzDk23i
YZAkCD512rMbdxOacY0CrQMPu7bINmQAVI23l4Ai6e+cpFfW0axmTuC19Xmcj7u/ghfUm/UcEeXN
mmeh7HR69FcEraE9vobLeopYqptUlzqK1mWkQ8Bd57f+vAOYsve8TiUhE9xWbMSvgl42wQbp8Z/E
vW5SXICx0xKO1elNYlhs70PqZlUUFnF5ps5SoQke9Bq6PCTSkfyjumj8RM7zD4R6D5P+xOcZUKiN
LfcWQlA4afToKB+P0vaHnCEdJvVxpOw4Si8PvaD7mf4mEmJaOuMuqgcIPb+MDmIcEgvZxciQfn8Q
1/lkYR+ecyN2/B6ZP2BNqWQRSI1cyAwEGMJaR5C2ZCnp4//3VvIfEyEPIwGSaC+43MFpWyUKGUlc
A4OL/PFA/H7jkH50BA4JLeY2A42gk22nq1zbpq1NvolGQcAXZg0SMGiJfrtH5G4j0plBtHAaD5ON
e4Q5ELPQyTpiUJ48O7NNeAJREahGgRnAVhyHXAZE9g3u8hNY+KpAsGH+oYTiSVb+hEzJAjRIWj9M
lUf/jOoos32Xs2PKQre/PZEPp8judzFBMYngqJCpZqjbGU0WWwL1TvVVT+feEpWnJu8H5Dem5q5U
QfE75Kvk890Ecdo31qeUvJOWM3jZ/T50E3C0zCBY9Loya0JZBv341uoQ/whlAnRCoyLvhmUlhFAB
/VtN/uaOU4241wdXKJu4ulgnV71fItLKRuD8SPYKQmWJXlNxkOvttn7kwiZQX7Eb4xEHFwvJd8rH
VAflyNpUfzq3TLHRMgKSCmXJNOJypgcfW/IYs0ob0SAObM+1J6QoBZw4RDGaidRq9/b8z+CpZed4
xo74djzYW2lzVyhhq9ZC1uQz+zYx9R/Vbh78wqUbkjndmhMsOLHaTd7VRNO+/jhGD0oAmE3haMtM
+iPHuWHcXdst13aDDs1RnCu2cSK8piFLcmEQrztoIMo3UE+A/fStK43Wi0kr7MfL8LgPELg+RhNO
14mDJqKuLuoJEAUGqh7A2vEVMzZdxh5g0OrAfUF2vTzWj7vhW17/6HrWSTU5I0DTec+ktZtXQNur
hYQ+hCwubg4p93fKlDEzLkA/e3Lg1X/3GlJ8nDSBqS4eLJEglOwcs1A3ntORkOxUb9qZzvdhc7uP
/10RdTYja82Gn6YYRkQsAzds5oXFTG0NdJLBlkmFuTFTzWe8mIvbc7TULQP1BVec9Q7by5JNcr2m
FphIgMtCycEdc6Qu6+qKRDQL0pUmUTXU3OKQAdk5oUOVh+rjj0AuU/rA2I+Zw1cQ/LQT3cigfuU+
Mf3rEF5zfu5QK2sdI1azv6rw5FF2I2S9e9VFXGjCT0GoHyl89Qr4YIowIM26iqQYVBULFtxP/vAH
Z6sW6oeX5WDf1iC09mT5DUPvgouX/HYnK3HlSiO3sC6G4kXM7FKa0DsnzNy4JJ95IRHMmEeQfnU/
Txc5da+GTQ1r3AF++KQT0+9lnaBQmGbOJ5XApgiTz9hwL0cswgEciR45ItUOqj3EA8yKso8TWuMB
oShdUrrwi9d0m2wGOo/2jVci9hlI8baHU/t3znFZs5IW2SADVU7Mh3i1ri/AyKyeSFUHyMsZhb3O
SwBDHtuY/JkcdikYnE6ZwbofW+9oAc8el9flSXf75Vl2OOI6Lm0ENY+ewndH8fwV8/bcoW+0/X0i
ZhSk6JLq1RWAvW8nZlOGiIWx7twZw6y1rzxz0dFJHX/2aOkwax90mnMoIVGU/mQ/WM83T+9SSwUa
7O3joGSk0GvCQGATpqK+Vsnz1t5Or9a9zGa2e0+K2+DzuhP0j02KmtXhpIPSiyFyQ1bTWRGsCgxu
Ye/DgvbVjX9pVimtEOuzhVlFmR9MwaMitgEW6s5Yxde3eRF0sMZTOEHxsbi/nj+tppb8M9DYaPuU
J+6uVOcM6iONH0jN/gUOtk17sCs6o7mUfDeNDdzuVmINCXsE9ASlkSENnGNgMDiBtAnuoha5mpsS
NlsX5TJnq2MMaGL/xUrG+b4VBKX9VNp+xAzbSFT5Z8XBt6dvV3g/jT3BCHQ3qGlYuv2lzwwEbYnp
KWrOutenDZDusQ43OrHWJnvxs7GaQ9EBM+8eb20H2kkEI0k6jYKAGXW+WOiDzdN8qPSZAs9F7OX5
Vrpl8l7zN/gqcRdKgZJN4X2chunQFfm+1/ClfTetIwJl42GWpns5HVwm+u4DndIJ4DWIEfihcff6
Pfphb8WhLNgsrc60xUkS3bo0IFOsP5c+MPcpdh5lWmXAPc6mHAqpT6UKGscHT13CYnumpN77qGI8
LmX0k0XIQo4onx7iH5KTlr+BYdzcyhDue0McjY9n5sAuhd8XkPe2F/OCPkQHGmCBhB0PceSFBMTO
wt4uwrrBAGFum6taOCQIR8fQo2WUPI4TocwIrpKgcVF1zpVVvcOprLsaPS8BO7GG7VyAiHTmj5hM
8w5J1zsvk60n1rq9riDC9rM/RRvnKA6e2FXZ3EDuP3/WJfe1XuW56mgd9IcnpLj5UpzgwnEIhuF5
ulkHglrTukN3gKmJhxnwl+55BigN5BZydDV91VXj+fs+oM8djLtbOZd5sFJ9RN3FtAOe/YU2N2Nv
mvOIQgVkwQ9DHRskoFXXyi0i+zqO+eY6+zFF+qPM4X6/1sd6fb00C5ek+ksI91NbQX9g0RM6Etam
sMKtCrpw3cIBTQFZyQbx+SDYsTsgQeQ9Cmyr8apNn8Q3sQgtkcKS49LeVuxbqQrFyzvgOykTu0sv
4wIjs1aSgqO/ruFDZDWDD3JFZGeW14qoJTo0UWtwIJyfcZP6q7b3aUs6G4MxR+CtOlcPNXKa2R74
+PZPkzEa9fUbAfSJqFNqcDaKNaxjrVVgVefiG9kyn906FluX2gqApDSVTr8sYdsbl83QGn7j2qxt
dvbhEFVAncJOuTdSsfqapfTmn3CkDFgtTvcG8JYPaJFGHDTU9BWmahRdqQS003Iai+7xosITFkvS
QaA7g0MhUf18MSBT2Cijz2VcZDHYe8BF5kzQpuNwDKF1bqp9ByA29wdFYGD4phL/gbwTBWr3i8ij
CSKC87r27iHFRhxvSJfcu0PFLJyElroTsbE9p6q5u3Ug5Lqi4Qde8flx0Gmx/ZlWbMiWjqV/SXPV
AccJj27hRg+Fp3TW7X5XgO/4ds710+jxGG/pDbq5viXi+84gYsFmir3nR0X5VId99k53gtUTh8tZ
OXFBuBBfuj4zHZih9fxKrN3HXp7prMTt2NaJmhe6/Bgi11jlcGw8FyDcqpzgY3+uzayHtrpYia/I
+00Y7DrH7wx0YCsCQ7H4ffZRugXTj4ysrK+4nNaw29Rc9kKto0+7qQUFGF7lIA6N+SiSSsF3xxuB
PLxarcRnsaiRGvqMN5Yr87QmknZu4KgTec6IvGzQbntKlSIEn4aMoaRIChDxDq4kvEVZdYGma0Ht
A6nWbj/FL05LS0APdIUERmVFramsbsTLBHmjHQRL7PvFiGb5bisWMwlV7M/z4b9UgSU+mSvxZNvu
q77J8NXZxd1V2Ep2SSDn95avy205XFHLIuB5CXPlryRM95s9G7La4QxD1LvvzJiOheQ/51hsLhJ3
NUjDTI/AGAQUE2lVKrX01a3JDE/9eDW1BC6xfJu72JK3ZPzj78Zl80F4kk6zgQVHihRAOl1RvsZs
y76uirHsh6Tzv0FdlM+3ms/jBjt7xkndfFRNa2xheeiaGd15POdiQsJ/BPfsux0cVuhJjZ1eUoXr
uxAIyT+7ePO3RLag+I71awLWQzOPOExJkzSi0IpgYdT8XFGKapcyUn2oi0==