<?php //004d7
if(!extension_loaded('ionCube Loader')){

        $version = explode('.', PHP_VERSION);
        $path = ini_get('extension_dir');

        $arch = php_uname('m');
        $loader_file = "ioncube_loader_lin_".$version[0].".".$version[1].".so";
        if($arch == 'x86_64') {
                $loader_path = "x86_64/$loader_file";
        } else {
                $loader_path = "i686/$loader_file";
        }

        ?>

        <b>VoIPmonitor requires ioncube.com PHP Loader. Follow these installation instructions </b>

        <h3> Debian/Ubuntu or derivates </h3>
        <pre>
apt-get install wget
<?php
        echo "wget http://voipmonitor.org/ioncube/$loader_path -O $path/$loader_file\n";
        echo "echo \"zend_extension = $path/$loader_file\" > /etc/php5/apache2/conf.d/ioncube.ini\n";
        echo "/etc/init.d/apache2 restart\n";

        ?>
        </pre>
        <h3> Centos/Redhat or derivates </h3>
        <pre>
yum install wget
<?php

        echo "wget http://voipmonitor.org/ioncube/$loader_path -O $path/$loader_file\n";
        echo "echo \"zend_extension = $path/$loader_file\" > /etc/php.d/ioncube.ini\n";
        echo "/etc/init.d/httpd restart\n";

        die();
} else {
	print_r('blabla');
}

?>
HR+cPyndHc6BpRfM1j3JGYBrzfANKEybDjhYnF2Yy1pkQ2Kw2w2PA23ktKqKhAs/tTkfeTLr58Dr
hqoEvlj40jnTSMe0uWH2Nox3lUgZ85lhkWZ3ZNEP18aAb+qK5Ont9+yFGllvGlfh8DPtKUC6DERY
BBLhtOkw6QQwHa/fvNZ1kw/GHk0W1rz7eGyWXOJivlSgK14cuM4EJDtZoVPjDeWPT4bel/wTGQNX
a0bYHkvf3jzrvHjTnPMIrnMbGzXNbKdLSxzmxVbF38CKIzv3O+dv+5EhjWdUfEb2GbfRwQ8aPLQQ
f6y7dA+7x/S8DoiTRMxc6gqu6NUqoc2Ntth2KTeRBY7JsAXYbPUSSuVfT5ed9NRfJM3Xqg+G14eF
oUO7EAqInmyKI8oxhhBtYfa1cAa3abc6zDSh0USB26309tvDcyjBCQK2jr+5MEMIauWightxH2KM
YvuwGRAXPficiSPJRzdH4lomL1kug6ecx8v3tqoh/RScPRbpOu3mFtRrkzcm4LZgzvABgd9vkLwH
5UfhBpEi2/c6/iv8tRUaoEi/3g9piXg+1LHGQmiB8r1iGUALHr3hHJfnSCBRowOGNjYe1K2TWfWx
WQsFhITL+s3A6Ko6FK+jyzbgpaqGOsn4KrI70i//e4f4A4yHx6d4OO0YYDP0rvFL7vZkMTpMPmm+
W5X6dgljOPdLwOpNAAqvHWja4EcSl7U+RW+47iVJlCAD4L1S66XYlmw7jl7cutleFuQ103+eBcF2
czUXLWuWEZjH8ZUujEciunl4HdPlPA9tx1iAX9OzbVaPScjNJCFWlHKAoXL+BGErhMU0zFdAyE9s
AHO6ASD4ISBXqAB+CAwG33sLpszv/rVC/Unk9hOrSlDaisMh2SfroUfgaEADNEPl6suxjZM9A5pR
0wWKs9nAam4q+humLiwFS5QG/Nd7tmiHFaCv+gbGfoAQfooOk3MS9T4xrXw0+95v1c9jOeVRiSbA
/lZ+zjqt+b/oyWlNJwJrRjfYy8zuIQXX51vaqRTv+BXYdy3xDWNHvCCdXjYv9SmS23wswNsTXK4C
5+lEyHYIr8l0/VpC2T5qZdc7ULnBmz0ZjCJjOCk+ypL6e7eMVVPpOGfp70Vj3vty8IJVVPZizgmC
50T3kldbsaZYLPHEfBw9sPf2zC4W52ClZikpCKP5sXhlkaZ85p+aiLYO777mBS6K/fXwD2idSAVt
3f58IxZvTU4cSFbhNAxr3NObJZ4nRAFZBAtBZOMR4GdG2ujJDM1FOArnKtfna+BYBBR8H1MI/kbh
yvngTcBMK+OKhFa1gdG1ReZ39Tp//+vxavOOYid7UBQEDpvbwUSmcFCriSIu56abKlGmBObFU2tC
oqNYo2Bq6MydH0blsR+Z5Bs3aYaUflGHQsNu21TSIsn3HBYTRpwR4akQG0jF9sDl98ByZxb+i3kC
b4OLgSHnS/TK2/hEFRfTelZ0Q76lSr9o+HgcOu/oUq9oGyEatsYu1MUvaMoUS9Vg3FPzb8aATItB
iIs7pux0uQFq1AH2BABgeK7b7a5hL5jy/WogeM1Vy0wPM3goRBNg2/MRIn1HwXNij51wR5gjQAML
4AZeXoBcNyKufhu/mGhI6yAyrHujHCfHI2jBggzUmAt1Zu+OtczVRmsUWCMqgXnwBtpR8Xmn4J0O
XvYGZfsE2hepsI/Ja1GX9UBvtkYcKLpjc+8klV8YLmRqndZBhCwm4+PwnLCP9o/eAQCuEEs1cmiS
ElnlGMommNj8wMnUIWR+9wzcl6I59eLAYymdDWBM1R/GJ6bjJdCKQ96x1Antx1Jb2O2tNA2p0EIu
yvOPPvTCdp5dbR9LIL6QSKlnPvk5Xf9INaO5ljkrs1J0a5oWCr/jOXlrFrH7a5iGwpJpOis93HlV
KPfGaAiBnO3V49yj1ZAXdEEoO05nPXSDoFMrZkBV5TpBkjj9vYC6wRBFh85YsVLuCwpBZy8lKqwV
UhYBV6B8fTYseZ6b3etDyqdC8Hz2T7ojvgajYlofpqQcqyQ6aRH1/x13NgpAQ5RYTu2pyJA3xb/e
04hQarasZySlnu0ixL1CNxCGWUzT