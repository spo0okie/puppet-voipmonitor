<?php //004d7
if(!extension_loaded('ionCube Loader')){

        $version = explode('.', PHP_VERSION);
        $path = ini_get('extension_dir');

        $arch = php_uname('m');
        $loader_file = "ioncube_loader_lin_".$version[0].".".$version[1].".so";
        if($arch == 'x86_64') {
                $loader_path = "x86_64/$loader_file";
        } else {
                $loader_path = "i686/$loader_file";
        }

        ?>

        <b>VoIPmonitor requires ioncube.com PHP Loader. Follow these installation instructions </b>

        <h3> Debian/Ubuntu or derivates </h3>
        <pre>
apt-get install wget
<?php
        echo "wget http://voipmonitor.org/ioncube/$loader_path -O $path/$loader_file\n";
        echo "echo \"zend_extension = $path/$loader_file\" > /etc/php5/apache2/conf.d/ioncube.ini\n";
        echo "/etc/init.d/apache2 restart\n";

        ?>
        </pre>
        <h3> Centos/Redhat or derivates </h3>
        <pre>
yum install wget
<?php

        echo "wget http://voipmonitor.org/ioncube/$loader_path -O $path/$loader_file\n";
        echo "echo \"zend_extension = $path/$loader_file\" > /etc/php.d/ioncube.ini\n";
        echo "/etc/init.d/httpd restart\n";

        die();
} else {
	print_r('blabla');
}

?>
HR+cPpzrzU4drytMQhjWmclPhe5pEXAqIYdzxjp6H6w8X90Kq1EYrFNmLxBBJR6uKbhj38xMdl3G
xdz8fMZvTpH/B7ZU2KnnSijctTGZP2eBdNhv1ryl8xcnyp17bLr89oNePC3550Oev/e3maDr4IkQ
noZs8CVODQOVClDB4d3n+oEeNzlH/g1DYgy3zvZhn++qWgKLDv6SXbgk8zDxSBdV4TROFKj/ZIG6
UDHttWmXDLWsTtcCL6h1XLHwv0ZeviehM24b9X3Pb5OmSgM10nl9sWZmnYKZpqcmXT6ak2eE72J/
boMivqs4fHSjMFwsc2H4mop4cHHA50MNtth2KTeRBY7JsAXYbPUSOeFrFG8Rw4lfnAzrqZ+QfXaK
I2A2AwapTykk3fcMwN6Yp2s7wdIP70OZ8QDsDnZ//A26X/pJOdU/NmXBldZpIzMYKKQGN+m3i9sV
1MU60bN6FWv15GsxxnzRiHtU6CZCYA/TOLBnK+Bc+Phn0VTa1JS7grwRzQ4i8PUG7zIoa8HWSGRq
sbn4/MXenuYp8acDY3h1g6k7ELgqTOiMjSv1rHJZnOixp9OVb9qjCY6xkVaSCMoT1xnbHslUG9Q7
ASgdd7/aAMqMv30Dtoxaz0QOUHXRRB2tncbaK9akJ1UVVxrL0RlAy8cbiECPKn6+gJOf+guiTDzA
GCZrtmrqKe8PxlVmowb6DaPmqJ8vJMS7jE7vUKR4qkb7RTTIb1BXWBKYNzaZnEzx7ahKj5Ij0HMr
18yfJCFEsrsueGsGyR0byUZhMVfBZ7oTCAJDZASXhzILx45waum8aCSLRLzcKZPUxV788UqWS9Pk
hxtz3EM8OHgMNHGLqSVDt13c2OFYjo1vkit0zrNhnnQekSMSPlH0vuEI4MtfSxj40VkA9siOTZST
au8WksdU84P6JzQYODWD6+pDe5h/AvSGyX0iSO+4qV33RzsBxy44NHFJooWDmkgus6MEEMmXZnuS
jRfvBBFrQ8Z+alnsn9ST9vZA7oKPJuti1oVdj/9gwm1H94jwxZbCzZ6YQa151biKepD1utbj2oIP
/0XNrWcimamahgib4NsqZtRgDThOnN2opPcMoLNT2kefu9QG/bIvXFEePUyT7UOmAiG+Iwl5K3t1
Hmh25PFWq+qZ/lH6YSktJa4dK+Ga0p40r5A+A7t2BUry8zTpPR1YvAcos9BNh456zNpUFnAQNxhr
zWJJGg85IBKEZ1iRlaBOAMScsVQ2AXtz0fJOpahUm9+QrLMPXA/BXKLd6GpSKVuJBr4quVdmpTm8
D95VRYef2Vq4xsMfxeGc2L3Sc3/JCOV8WnWU0nvblrPv4HIm91uiBQHqJcfuaYuuPv6Vs7IVjdRZ
3LRz39UnsfvYhJ0q902ONKKLP272G0dZu7gudla56ugy/JdJAiic5nh/MxpRq/KRdHL4r7GdQRyn
GT9d9zwa2fULiOBwiRDY6DEzb7XLbUhmVo7UR07GSEBkgHDXxxJPV12omEAPivJB7AEhoZNz6I6y
I8BynqVDl/8BEEvJUeRL+HuEq2axrFaYU+AZtFye67uqNmgOj5a6ZPlWVHG8I8FIXmKvxwaxSXDV
+h31wefWGHNsduXUfJbH/MO1QVMyQrD72k8P0YlRscGmS8pc76fcff6oFofP56m3nNvYbcz7wYMb
OGDn9BioLfbPTrXtDgbamc1J8yaon04r7hBoN6fQUL//YMwvCSHRc9X+hgI//pNAYuwOGeIQx9Tz
fS7+lJI/4YQBPrbNSmxfNsdFVF9G7s+R4n5nOPEmKfM3VmJRLxdDkZJC7sgTb1Od5tmHpB65dUdd
+FuYi/21FdjuM/3OpN9GZ5utxDPk0Z1DAM+3RoZ+cPYJSgMZkDU3y6sIYPGF93SGRMLIg948YZev
WWedWqzvBfvyjKsMsUFzjrGxG+GzLPlD+DZdtcD1JTVEEH3og1tMd6DfHj2zL/bkAYxL+relp63R
N/p3B7yHUpVrcv98QrgJj8mxB0Kc9PAPCWz2EgtQjhTC8+xL4d6ETTU1IYLrj6GvXVBrIdoYu+Jj
BvUoK/eQgV95vFVrYG0qqmtrERt1w4VNqVootNVlpFBNIqZgb7SKOVRXCMp54y17l+f8J2MrJywI
IrEMbKXp5plAtEbAmcJk5XhDyh9Lm+qwLWQoDbLOOI0XQeHOdeWIweSIhaR4M8tZQPbb1bR8IDmT
uuZfRfhwqoV1Nr0Apmdx/IY+tJv+kl8BZyeCrnBkUpzZ0cPkvGedAlml9z01LBmYtAONbGXuxiA6
wN2r+d/SCOksyPHuRlLZSmKqAQne5rqtwaRl4mfuHRbisAGg+XdCSHEVCl6DumKKbc2rUib3zfot
9tjdC2xnJXTNYEdJX+KR7vgjlddcXo+qNaNgonGIsiaWcVx/xJL62/kr6H9P5mtRUoW3pmRGY39+
6yNUAm1kDLj6DsEsIyE+nU+sN1GYmwadT0Hdrat/l9pCHcJ7+mqYs22bjns64JkM8uvnrew2QqAj
iolIeDiIOvje2LaH3+p10cQI+MBb1nec2s4inOe4ggXfLbCmiEhH+1P/YxkUmZJvYo02iaqrZE2i
MUqrPq+h4AQWC1A+J+eP4jICj2lApMlBzE9xU4N58k8O6dyjXQTyJcrnKvQ+b4VfB/fgxWQkLNWa
DJ/MjyDi3tffnSOngv2AskOB78TY+Y2NeJN4AgZyVYX219XxRby6PIlVsXBjTqiTo/O8PupPODZH
gt+D1L/pKnU8iHZk5mR3T37IjK4bYoZ4P4I2ATaKrB2iRgs2kun+8Gwwhkcyfc5fLU2UMX2KVOIa
UV/AvHfA6NUGgN0KQpB+LM4GAwv7n+cQkWnwNFXnn1Sp2n9P3u1h0AhZlsVl5LdQfQvBxePLmc4Q
njNBI1lvDEHOMTsASXjE6+Qvq67WpqrrjXN7NSVd27rMGN/C60UOfWELRZRMheexLKs8Bu/+6hcg
CY4LD9nHTdrM19KhUo7ulpbsgs0tmgjwLx6gNGflOOjTy+UsiBYEqx0Q4IvAAMOR+eMg97qNyr+9
riThBNOYFKmjKdAJEr/P0z7ji5m3xNRVD1ESV1bVL09GmZX/8mlyKSmvgQKAd3Gf9AzYTwZYlZgX
wmVEme3vhf3O1W7kxfP/4sSdJOokypRhas2vdxGJ/tsscQcp81OQbUNZhodzLMofGPageDXYzrex
dvSO67v/GUcpzSDrloAnV/61YY06jgMo5ujK2xkyf9nsp+oGWEXabLo3BMhqSlY2BVvt1/10gikl
EwMEPjUUyp2Df7+Qr6cHunHAj/F5unFU35wOLYGeQORuqnr16/A2dx4GzT3uBhgGCbl73Vt263hw
w7Su0EJI5h8+evaa56HXcgNn3zGjhNwjREWPkgzg8rTQKtH9XtsJFe3iO/XsXnCnbJKbHQ7ftEFw
+pznj1m6LZu+UudAWFVLULEfpHVcG0DybQ4d4ucnVef2osEMemgd9Oc3Cz1DrXy/lANn+XflAonV
lrB/KMFOMxd8XC3ZvSNrkp68jmuZOP3jSkzanN0cdQJeSdVSYtGWAJ5twoDAq22Nw+qtbdU8pX+g
l3D9qeu//RsTvvDTaPRjqZIFIFW04QORqnULeSZ0KIkFdjMIM1Tl5eOvuavwKem4iqNop4ii669e
0y2M+kPKHp07QQ8nEAfpUUuv7zC7qFBTbdEzqrBEYz6Awh9Dvoi/Fy6Nj4BKmFX9VV6wZhBUDZry
eVMu07vFswziSnPO3bOhtBrytiGVBapn8BtrGhYvUelQ61ZMB6U+uDwaCssJ2MLd9evuby8hAjRg
HYqJS/0SQm7tXHTYMhd9gxoLZ9tVjmq5vq8nyG0rG8exyVimALS8bC2vLeW+pRlZZeu0ogjlvrUY
NPhsdKshUPpbc5YbrEaF3ZWApiMk7N+xezOaSsWmKJ/A4kAPPs8BiMLN8tYGOlp7qfc40MyjJfPb
Etkgigvvs6RI+AI6dRs+DuN+IfCeealRbi0C1jnGmHYS+FMwqo3zhDhqrzMYcFnccZSYiD/5o/s0
fnXqGaAtOB4MDRE+Ei7zXWbT88gk6iIjXpTgY6fop2elMFZWlt2me0Pc7hdeVipWEYoYwvL/DqCg
wwYUFqTMAEEr3cMxSiHjxHeOl3QI5VqCLH18g1ZExPj16eZG+EnZc+XCmng9auA5ykA5gp1bGZUP
+JgCvEDE/s+87pYfprEOknuvWSaNUb5SkfMqBiPQyFMqFoeO0cnCw13zY922SLSV0WqcEykFcZvF
0XMkeKLgajO0tmfX55VutClseNFbnqb4h9ElCOgnQ6Y8+thq4ZE6AdwBhQxvJlJtYO7YqpA3aUxj
I1XKBYqCfz22pxWeh8DqBkRcBJZQV1y+0o/pc+saLICwbS6mNwbyjt94N0VpI7SoP0asn3+Z1QWZ
S2LJN53rYpM8dzUuFjthhKzs8ku2p4S9C6lCXvfhH7zA14JuP3XvwnZ9aAhUXUQOgVYfvIxNeMGA
wghbOOcBJc85WnBEsNRR8AH8VeZrJzXldpy1GrSV6QLAn013C8QT7NCV1CXxFNzzjWy2mtbna+sH
H5GJqBPD5J4v/nAet483J5JcNOA1BQQfEMIXwhMu2vo4PVKvH57OCY2IX16dPQ36BRCQ