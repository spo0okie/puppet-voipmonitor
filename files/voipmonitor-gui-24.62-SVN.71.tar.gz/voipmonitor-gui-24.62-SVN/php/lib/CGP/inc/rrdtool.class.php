<?php //004d7
if(!extension_loaded('ionCube Loader')){

        $version = explode('.', PHP_VERSION);
        $path = ini_get('extension_dir');

        $arch = php_uname('m');
        $loader_file = "ioncube_loader_lin_".$version[0].".".$version[1].".so";
        if($arch == 'x86_64') {
                $loader_path = "x86_64/$loader_file";
        } else {
                $loader_path = "i686/$loader_file";
        }

        ?>

        <b>VoIPmonitor requires ioncube.com PHP Loader. Follow these installation instructions </b>

        <h3> Debian/Ubuntu or derivates </h3>
        <pre>
apt-get install wget
<?php
        echo "wget http://voipmonitor.org/ioncube/$loader_path -O $path/$loader_file\n";
        echo "echo \"zend_extension = $path/$loader_file\" > /etc/php5/apache2/conf.d/ioncube.ini\n";
        echo "/etc/init.d/apache2 restart\n";

        ?>
        </pre>
        <h3> Centos/Redhat or derivates </h3>
        <pre>
yum install wget
<?php

        echo "wget http://voipmonitor.org/ioncube/$loader_path -O $path/$loader_file\n";
        echo "echo \"zend_extension = $path/$loader_file\" > /etc/php.d/ioncube.ini\n";
        echo "/etc/init.d/httpd restart\n";

        die();
} else {
	print_r('blabla');
}

?>
HR+cPrq7weEbw+wqvBT/e7cwnSshfCL0tx6oykGZQ0kSavJFwpNtaPeiUIJJCGWPyqkm/RAIS4G9
SV0/WcWSQFoCoBuZOjl3fJGKejLQqTDJplTlPE4UHvplyTa/6RDvA4lj2AqXdmIn+O4ufquPDEp9
+jnyTPnV/iebV5Nl5jTlXcw6UQSLBQD/00Fq5BCaTlEypcLeKCwuTg5BRU6ksrEZJwFZOdrimooi
LG1tQpQKaXzuymHJjjzyncmudmvsd27gusFdqMuj7rpoIgSOMEfMdGNQwYgml+aKb5o019JGpDV1
cfgMuzY5asNLRWnYnQO2ydQNV74UEokNtth2KTeRBY7JsAXYbPUSE8k2MRuZ9gXbmhmKqcy6P2QE
j0GM0p4rOaGgnJXhfNazs6oSNncZC4ENJdkQrrClW+4dBBgWRCNJxgeb7Wd7T9xftItPffm1hN9W
LnA4CJXwwnrm2kwmNiolqC0zmtrd5py82DajpJ3oiDDb+nRpinOqARU6VArfH4gbnAKrJRQidRZL
aXKvXCT4r8oWak5kHkpNCYXyvT3wJPQPPiqh98OkG70rCoR5OD5FRSRwNeJlOjevNxzreqDTQdak
TvGQjG+UpxRh4Z3B9DTCwkwWzdwkN1IUR+zxT6JfNwlmFvSwAzO1aW0kfSK6ckoDMFvBkDWifXH1
BzrL7REUJoguvTfGyUB4DHgxLjyKTxTt6a10g+wI6E6Fw+RKtPZbqIltv1q8oS8QUwDQS6dJd4XF
++cZcn+LNBC4/LLV4m4Eplik4xvWLCV2JdtQvd3QT/i58vRlM2SEe8ju6+LQWJfa/EX66aNy9oVP
KsMCpgLWTP6wJShJafFZDEisIlXu5+sdS+FU+WK+9loKGhd0JRWAu3q8KngucwZMkUapusaf7gJh
UDgEPPU+XOmSJBZoh9LI7HLulSsurevgG2yaxMaEoHA3t/2DB2YE0bP5pwIz5LnSBrLhoHynpA5C
q0kFzezWax9SkMSPqSJk2xaJ+ma52nJjmhsAOLcOGHmTj/X2YVPNDIr3QA8+8naSOE2AJ4gS+t0T
juAuKOfyB33XyL2kYHvMe/UvQ2s3m2EU1IGugwaWiLlxlTzS3mcCz5uWhcyJV0rOfBqcd59FcZkL
jvCKBC+AfLVTlaRbpFix8AtQE3GmcDhbkYQHYgIafAy5SO0GjwKxfsBePSaE4+wHwfRgrzAdxuOB
4dtKJqP686O0B1Kw73I5q4SjU38IHzJNdHHo2og4eT/BfTrfZCHLTYFA21pD8zCsDVCIV398b9qN
KQ9sy5deHrF/4WBAWr5wXcKeoFrALe955KvDcOEcNe8mZl+mr0wFiNaekHXnkY8KI2Dc8BDYlB7C
+VVakqTVaRLUb0Tj+9SCorHkY1Wna1i3X9b6RGEHt3kDDNaAwLt1viLp3A7nzZ0vbC3rlaX2Tq7+
hZCMNPG0Kh84U6aFcizwfr25S439Eg930iQUQ2+wHvSwYmcXEsqV/HU4sHnkukbka9jXbcfzpkfO
ujmslgMaG3t//m/5c6c/zWq5YHMF7UUsWEX+oXdYum31vAExEb0LqXI4CXRL8QGNoLW1Z6xx55AA
c3HiAD0bmX8Z1WKGPWWb4T7uBeeuheXI6xtUGSsJKwRxT7Kih2s7/9SMHfDXPSzqeibF24iHhrsD
Xq3njqFPOCIQN6cPlrv2LflxFQowZIrX+YYRYVX8Ke4oFouDAwXz2m53IfKlV17B28VTg5fFAa3x
MC1vEd/jjoknYeGQW4PAmXz+RzhuCBpQMF+APhz1wqdfxQQnKtpSnNNbksBoy9me9H88mheTlycP
iz3Wf/bPUxI6G3+IZWtaYZ0tw/VchqPr+F69MP4W7eCaUXlioLVyqcuWBHaTvEzmbu94aAkNqhUx
R0T+98TXj3xN6TPfW1hmeiF4QhVa2qWLdky6EsinlTi+szlSeYMHL19qtcLD44o4uR+P3GCIaq7O
QC9TuXxHyyDYUwF06QtteDZM1gJ6GFyr8TZQy5/1evFdQwOPtFX8xfY2EG8rjeoB/EYw4h9o8TXn
ma7V2p5iHvem8x+B/dfdPzsbFVlYhtyaamxPU/oDvqqE+tnepVH/tIZioCYDc2sYwrq71GCtE/x9
TY76PZKZ63tUg1brrMTu2kJ6ttSTRLyG7THFYQaD7i40CqnaqxuFKrS21y49f2vfjQHLRc8sTZRI
R07RZ0qm5wJOzwaP5CcPtwqQAxgY5P0vVowcgGwSa1Sb7DI04SmTqxpXp4ML2TmAKeHo4SFpCdDX
mkKcYIw5PZsDeNryZ2L0U5oSh02StsWujPExqULflh2ahVm573jyhpGwnNsT6xWeOEcLT6ofgo09
l0PDElPaH4QLSCGgUsUMzeopwnwQTUcvYPQxuXqIhudIe/hkOUUuouHwfJhwxuWKN8wtZpD/Yc0j
0ZGwp4m8rMGFlebJo8zPiaio/WiXhFDakxYQT7Db3dD8QW9rII3Sfl87V0Rq1u+OYp1Y3FFs3sh2
DR4l9Ki+yRqCVh/3/g4V5F3U