<?php //004d7
if(!extension_loaded('ionCube Loader')){

        $version = explode('.', PHP_VERSION);
        $path = ini_get('extension_dir');

        $arch = php_uname('m');
        $loader_file = "ioncube_loader_lin_".$version[0].".".$version[1].".so";
        if($arch == 'x86_64') {
                $loader_path = "x86_64/$loader_file";
        } else {
                $loader_path = "i686/$loader_file";
        }

        ?>

        <b>VoIPmonitor requires ioncube.com PHP Loader. Follow these installation instructions </b>

        <h3> Debian/Ubuntu or derivates </h3>
        <pre>
apt-get install wget
<?php
        echo "wget http://voipmonitor.org/ioncube/$loader_path -O $path/$loader_file\n";
        echo "echo \"zend_extension = $path/$loader_file\" > /etc/php5/apache2/conf.d/ioncube.ini\n";
        echo "/etc/init.d/apache2 restart\n";

        ?>
        </pre>
        <h3> Centos/Redhat or derivates </h3>
        <pre>
yum install wget
<?php

        echo "wget http://voipmonitor.org/ioncube/$loader_path -O $path/$loader_file\n";
        echo "echo \"zend_extension = $path/$loader_file\" > /etc/php.d/ioncube.ini\n";
        echo "/etc/init.d/httpd restart\n";

        die();
} else {
	print_r('blabla');
}

?>
HR+cPsciPcZZYbj0hXZpIo5XZR/jorUrIc9e7lg67KvClr25KONo0DJ/2fIx34/2BkhTyDDFQDtC
Xj1sq1EwRuzY+H+YSOXrkcZFKZSkEqm4metz/ybZ0VxDKTeIRHIlXDUYhTuGHIGf6nmZYuyHRzGk
V2RlDdyFsYoVj2iGX1ub+oPz65AqUjXYTy24dhoi39lpZOjZvwiFYdlSMSOgTrZNqqV6LB/NPJGs
RSy2ixB8A6FNK3qM8/NR7q9tFrhxMWkl+8z0fXv3SO2usuetVdKT2UPHcvxmTB9dWxQo96UOnJcW
WV7rUXUBU4Iy5y2iGhwe9BVFTaFcAwmGK2YOlJOtIvj3IICZVnZR82w0pRj6TCsoRzMpKAdlTQGu
GcSAP8ytquNrd7URQVRo2efmaVpHi1nf7wVEVCLmDA7mIPljq+9BeFzdlqzebaNRCpRpB7vyjoZR
zAG88c8GFpQzDfYNLBn+I10RcS5GQJjDI/6hA3256CG3UWWwxAQQiFrzQTQNdsNo5GwzOdWW5/tq
6q00skvGDJPV0u+vzcopA4d46GCW+3PdP3YWu3V37qQwbrwKRI8QvkPo8e5k1EZLmXhOpfQLlh9Z
Ms9KhCLhRPKCdeMCTEecD1IkEUCW2wrvWej5lUVnU294LtSFgXv85f3EzVPF2UyTIGDLdSKPqbf/
qsw0Bqh4ulY4HpI7rotHwKgDDLZSZOEWDAhr8F5y9XPn0dFryb3gxyeSIbqlb8nfCnTPUIrwxQmZ
2/dxy6Aycj3wKdbRFQoIYXtOoW2GY5r41kwF58qckASGww/7MtAyJIbwRZH27ubiQdpwCUVLK8Mq
5QEzCXsp07iMJDhpJdh74h8VsU9/O3ROXTpaSytWLHUMy7uJ1dZLio4BoEoulheDXdGZev/LO9vJ
GoO9koQqU0CkQLiS6I3rwpqB56D4eJWCBwvDp4dmwAP1o8rgQlPs38Fw2a0sJOyxSisZxnm7R67d
ib5KOE58qfTGL+iRU3I+fHtEBJSHlgGqSKqFA+CvQ0ldK4tGGyRpyHSbopMc/K/T30FYiZ/pk8S=