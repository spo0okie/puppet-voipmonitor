<?php //004d7
if(!extension_loaded('ionCube Loader')){

        $version = explode('.', PHP_VERSION);
        $path = ini_get('extension_dir');

        $arch = php_uname('m');
        $loader_file = "ioncube_loader_lin_".$version[0].".".$version[1].".so";
        if($arch == 'x86_64') {
                $loader_path = "x86_64/$loader_file";
        } else {
                $loader_path = "i686/$loader_file";
        }

        ?>

        <b>VoIPmonitor requires ioncube.com PHP Loader. Follow these installation instructions </b>

        <h3> Debian/Ubuntu or derivates </h3>
        <pre>
apt-get install wget
<?php
        echo "wget http://voipmonitor.org/ioncube/$loader_path -O $path/$loader_file\n";
        echo "echo \"zend_extension = $path/$loader_file\" > /etc/php5/apache2/conf.d/ioncube.ini\n";
        echo "/etc/init.d/apache2 restart\n";

        ?>
        </pre>
        <h3> Centos/Redhat or derivates </h3>
        <pre>
yum install wget
<?php

        echo "wget http://voipmonitor.org/ioncube/$loader_path -O $path/$loader_file\n";
        echo "echo \"zend_extension = $path/$loader_file\" > /etc/php.d/ioncube.ini\n";
        echo "/etc/init.d/httpd restart\n";

        die();
} else {
	print_r('blabla');
}

?>
HR+cPxJEcxs0cM2o2GGEdgRyObHZoHchrGZe8CLSROnNLz7CXZRWBrV/rcxyAQy+wPesKPRaS1bm
APar3YDnOUkYFkFUf7rpkXsF26Pr16AXaMjHUeVKVePYcuV/df64XnjQASqe8yD58AnJT+fqoE34
o270x3JOIgNoD1+OWtx6vWdA/JkIyfEHLqoN0rdnO7+tZcEF4/x9btNol/0Yd7dEd0QVt8ddmsIk
Q9GRyAtWBZU9BH8xMHxaEooFZLMUjn1/FWBjWaQFcdZqVuuGs9iTWeWbsl+O2Nfqy/MBnAsLAm0a
DqXs0dn00/1IHOnztgRrSglAij7elp+WryjZuSarwdcwgQGgw4+iIvUjYFxw0cA8ppfOPU6ZdmR5
0F+a92tO7i0G2/1rQzmTMm9LFqH25eGfb66WBgsIQNfz6fOeVYYEaYMT4C7AJpXptuAm/P6EW/dy
EweraJ5gKBk/KKiOZ+DHi7lLVypBmMfYZPeNubS2/haBbw4UI/6doKG3y0/LUmHY7IllbI3mGcoh
T2BpC/OztQD0KIYk337Cc2EYNQ6TUHH1ZO9frsH78Ti3L/8c1MJ4uySWJlPbO8qGnQ7wNaCBT7ba
tG3xTywm+PlQHchxjBNOeBY6ahAGWfJTecXYDCMAxEOYoSLR7rU7nFIZXCfY32gDBnXyntvZC4Kx
OJj+R2X1ZgIMggT8+TVRslUqpaoLe1MhWz5qkt8g/r3pP5/PL06WuF1xVM/HNAkLNcUPb3tEPu0u
eYnpY9K/ox6VEExAUBdmm7WaHJCperyFMc/T3ztec69w09IHCyyXHzQo7FbD1rTaFvBtviAoTRu4
LXAT/iZAcXNn3CiCsAdfWt/8nFgmJHaKwJ8RVG7OYX1ScFo8XnuFPasVNhjhQxlYRoEzI/vgnAfp
TiQyw63kOtp+tXlwWHwJZwvR0ron5Ym//6n/Fh5wA8nOjTgdIb3wd0IEgKaWfw2A72VE8sWbyUcX
wBI6o1qshNDDRwNne1HT0LjhxeUEI2AfjyWkhOioqoTSQR/gDCD/PhfW/dDRCEEaAluumn76RGU9
3mx/BM3nxKDbY3aWau/UsnmmEFUmd3OIYKC1QuLULywBBG79JeHnFe/8UcrKwuSSYFBCPuhRP6nA
sGuRYQ5KOtvkY9WuVGGTGYValVZCe83McV1zUrbQmaq4iP4vDfVWx2tO0oVev+6eN2cw+rJKVyWC
3hN3nvJpxxqtQ4Bt+J1xZMX4+Jf2ccaDrRsGaK8vx+GO3ebBcO0BK7Ix61er9cRzG2FigaHYo/+c
GPoVwS3dUjVVqfc1awzw8BrIu/4Jh35oSc5EZ05qNIuakwMOh33nGaj+35g3/1mnekcDNnZfjWWJ
vaHj3T2asbxJbZvfXnpotdwWr1i6qlr6cCtD0rrgC20bngEVcyW3dhnGNX5sDmIR6nuK/rGd0xLT
nz/B7SKlQv0u15w4xL8oVyz7lfLYyhwP5wclpvak/0cChk8az/2qnWmsU5k+XygzcPLdkiTV0n/i
EFQxMHz3v8jSxSp7XWudEaeVoThzUX9YFGjWTSkgqfNwhoGHXaIGgbJGdVw3bk1iXAeWVtfr5LNN
A7jxGIx+FI43pFmrIMeRAS669SGUcRSoLkTsBigumuMk73c6Qz+OcBodOyVnm9VGAeUVD75Y1VW8
2ZJNiFhdl0YVUkFPd+NjIQz2knLy90mWUq/YCk6MyilpELzr5tSJ5XQgt78NGU94p+jpk+a2ilzw
1gXgUZzRnG5G8zlwz/X5BSqD0VfA4kAFjefMmHXdUrhjuCmBwWTl2Ptb/Zd3aAejstP84j7GafoZ
BvC3M+nFEyT61r+QDbq4j4U+gT+riaL8989H46DtkGNMVD6wtbn28GbBh9QV0E/fqaF4o0mMaWop
VOnh25T6GuTp3rDSiwnuu41mkBJ64+LMfhj3ql6zpSAvHRYV5rt9NVtbPaxOL2OMe9l4ssRyXCAs
lNJiVt3gUHoBNZK6N2Vgb69RsQDGumYGU2enOjxW1UXxWWe2GCHddnHY+v+cfjCVwOZyHFkXYlYZ
5se8eezfW8YPdIJTKudlKsaPev9OwIVnEYGDctxVl2uYy+2sfglzO6C4oKkzXOCHDFg7x6IyJGhH
EqqvuTDwBQ2unxbRawDrBRQw9Z75I4mVWKXgkhhOjZhxI9KjudSdalLd/qVMcrqpeod26F6ruUEO
uHEjNzJpN6SBMC4rdv/aAF/ihYpCHnYEgG3Jh8kH69K/7tmKnDCcfUVuQ3bJw/zuFrS9sYk7/BHx
zITImyYLKSS1mYRbo55DVV1xoRZWBXHEWZT8+0C1RG3Jx1AM+I9jc8ja1xAMY6fjtCMSZyNwYIlQ
218nhHxPQ3RQb3Z7+qLi+Ay2SMa7RjM+5iEI5HbJbWTwWOT/jHNwjfosmiodQy6R1mMlwe3LwRoi
f01OWAkvKWtgkohoZKf17F/N81zKqeqPpe2TfLD/75h61+UmFv1Q+i/hpo4Ueaz1cQd1t74lltaB
d4QkvU5LtdrMU2dPzm94s2aBYM5HSMQkPzDKW6nTfWbOqb/EYjVik6EwJEzuIegZXP+/E6tUi8ep
+GqwmaPHMHsO6nm2rmvk+8sMoOmmWK44coEXro+4pI/nB7NBjvoYr2fJyGBwNn1ie2+Cpn9dHKgd
U/SGv0UgNAFUVEeX9YQSuoEMx891gRkJYjACo87sp6JuuQOBPCH2aKhD+eJ4z33v2PuUyI+rJYus
RMmFy0Pm7inBw3fMgY8X0BRz5F/yVILyPnJqfPDb1vDv+uQGC2TJQGwCBuj5/ze2jRIUkCEujAOv
cQ8q9RUQRkE4OzOE9KE10ghWpv/PnJqRCoqTGM61O+vfOEWU6pFBIQ+ke3gD/uj5umihQNIhmmt3
4bU0cm1g1D3BWvxmQZezT6cHqpE6aVh50r0YKRcyYRc7wGuDlYPd7pcSjhhmrPPYvyqcH5z/SWnL
NaA0tAOzdL2lYqZ350WOOc8qognR18J/gYVOQ4fPH0sHch92XWgQJ9W8rdUx+s4tMqtVsPZlhMUv
Ct0za+iKvFvl7qXBn2pMs7LTJ4+aKY29K0WrajeI9s9/3ve0IZkH7nxA7JqNkmtz7Vd4iw90SU8+
98pD4um9JVrjYolv5PwJ54HZMO+49aL1O4xtTziT/owaQIIu8ZRDpBhKExEwM07JRjHnWIBaM3EF
oa0pyNndzuXUYvKVcT2kl3N7az+NuFswp5iHLyHck5zoZ/F2WQb/sOLLzB5klT2CdmwZm2MBdAjM
sqVWXFPtAKqxsrzFRAFhDr4iBY27h5crDF1oXqn+/nRgvR5dPV8t7RnnQaoJpj6QbnjHSQeoTDJr
WYaNaPGjg3aLmg4Cer9YctOsvuMnFIPQusJ1tmdp8Ua1M8hFf9wzR5SqvNTWrUIfdAuIue7onmRp
Ep9sfJLnc90bS7bnioIWo7928GbCuSP+fgWgUEbhMK0XfGhUBeluaZPHD2+DoK4fwmF7Hl+VYh+S
1FyKev0NxqJ77JEHsd9QyM2OIGL9khLVhLWPVesrh6X7q6XHZezBfEiwqsVIIpyTz3YCA3DfJM8n
FxmBlOYnzL8/NmDSi9TeShd0LXcm8yxfMfWlCcliuPsvFzDB2tc7ZmnPXT4wSuAhIFnRBc+KOv0u
8T8VJuWEJwUoDRYOnjTESnjDsListBTppFXwchXkVuCGw/ZUMCkvKe6Sxc9SomL7t2UXYggR4FfR
Aa5IeC9Mwo7BY9/RCFmDOa/j4MnIpaJ0rlDsYuLETXgXWAKieaNvNl5x35Tnx7PEh26w/jr0jFu+
x4QY+D4npiehIrRNrkqaC6cIiBOVHd1/sQzTrDkfgbF1CjO/UIR/iWCOIehTbCxvKVZLwaiMdyK1
BOvTtakDlED53KechU3gVdB+05B5D9kk0DjfAqpj1+N5KR3sVk6aRt0c0XwFFjkvoe3r9jS8ywUT
mOO5bcc8nwaAFmsMa4h0vG2pSD+uAKYIclo/3lxbMw6UHwKKbxjG/gHQqJ8+s5Wo8b/N4sQet0rE
SOqTh4Z9ijFElPp4FpZbh+P9iDiDL24ziA1LWgSgz2i7H/1E8/wq6E07XR9QFJFWKo2plNZb9pPd
gT4necCwKOVlJyEHK6kVxGCb0qWjDiq/N6IDQ4iMQcuKTc5Zo8qRuMQrcx9uLZZYroXPCcU1x4ui
utzYgqPFTmm0ioSGtX59+tHjgmPaKNAFUfrHfvoRWSGwQdwsizYMgF/9vV2ED686NuODy+ZUWgOg
oxVPd0i4eITD8S2FqkyDfGxT9Eb3xTiB7sv1qfuOTMseDq6gHQhOvuGLA8dxPBvEo8+J64ZGMLPw
yFlTze2CQZGuA5ToVYXGCqWOujLSYhgLaLFWKOsmHnPGwimaK6/HcGKMI8ByJgobvyhxXqfeJajy
b38YsIp8mz93hi8ArEvKfkevtmCHH6T2qHNjt5YDKyK8QORx8ng00XbGW5Sw1TkOdh00vRk5iZOK
n4AMOvxenweVgBBX8pHtCSOX3Uuck2PQWPzcNP37ytI3NXuH2OkVn/wNILvMeLQNSmCWfQL/DmUZ
kRlZgDuanToUgm7W2jWXEfALtPtW4zpVtFNGdvPk/jAju791lzfOoKkeQLWAz3QAiVWMjoBD8hNL
lcJEkLKcQQXJgFKMjpDvYw/a4jGbTbb8RfoweOgJf20Is4V16pxzAOjTCBUhSjGZcQOb5dGbZ992
OsWwyvHLagLEYqrz3bqa4J6YbUTYaXFjQ5w2S8G2xZWvZN/sqOtTQ7PHQX/FHyisDNEopyDrMdkz
hqQJG6XhYf9mcCjF2snpSs2JdN3L7OQh4bCbfUN0CY1HNfJyVbfC8O7QKKDhyAwgITy/4Xu6Bdxe
5w+iGrvR1Ly/B0sdTzI9DFbhUeXft3j/wmeMlULQx9kTlm0xro8mpU3MFNDCAIjTEk8rTqhednqI
qbDNHN41Qzh8Nhpz0mNCxGsS4cB/ldk6HCRUIUjPGkd6n6kt7HZ5ylfCy0aEq3GVoCbOxGTectlV
rIMT1f9LJJ+He00u/OQMkr2MXfndlTXEdAlG39ZpV6htlm/CRwd9tfId+bwDCW7ymJcO/04/i8e5
YyNtwLinDe1GJ4bsH+UEiDsLW7v3RNauSmMz0BGJvtEPt8R7XhZsvQweizkBjVNZp29H6viccxCs
X9oHkK5vYYzLD/p4uObWufoaCykjWYNfO8LpkR4Jk1My523Xf1OaXnpA3s6y1elQLhqTCZBEuGLb
xpHAnV0zjMldxaNlE5l0SBfFL6zGBzzNN2bVUCKC+wsLo2Xow+ymCiON4H40jNEedC89c1/63BfP
Mn9voJYTWG9znkFvbp48TcJbbaivTSe/Lzr2LhnK9eJjTyJj5y7FY+hgtRSfHmJMO7VoeXYYpSbm
WFIbvohqLqohAC1ZqXl6DrG0lCPtPpfq1qcetrtlia1Nt6DX+DqJTztWdRWMmXo+AZBay8mngaRG
iRbf3Pq0fTU9QLgxz0wEuPo8OZJieJHuvpBBDKTSIInNgf+K7IFKlJIQcg1xIXo0JdkLL/G8PcRH
l7vwkJljGeoOXu22NzMeOezqG0zbBvtUED+dCkoKrvBFMQlq6y/B2wzTK9NHoOIzz9LGte+ZMAC6
oKq/LcsfHO79U1lcIhTkuuSS3lntL/V42+HqzCN1MbwY18ldOLGobU8lOXbufWyRs9WXlZquZs9x
atA62b3taKvsTeaWupyQrGG4AYaiz7HRoI9EgCPTHWLOGQrmfgci+N44egXqHO8eI6/AanZ/G6dv
v/u+6yF+Uj2Yu81ufnMENbG9DX3kiz7BDAOJ8UZmrx9SVXOR8j9Ou+qkYTG4YZtYTCct8a+hHfBX
MclBSgaFO77cMOEjVe7N73k61LAo/pyb2IKCr19SSOnd+Tb+XgMMpBBZ1/aN5QK+35UHLdqwzoFc
Vl7N+wHc6mZe