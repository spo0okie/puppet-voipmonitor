<?php
 
define('VPMANAGERHOST', '127.0.0.1');
define('VPMANAGERPORT', 5029);

define("MYSQL_HOST", "127.0.0.1");
define("MYSQL_DB", "voipmonitor");
define("MYSQL_USER", "root");
define("MYSQL_PASS", "");

?>
